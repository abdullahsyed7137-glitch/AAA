# HM Client Manager: Build the Android APK

The app is a web app (React + Vite) wrapped with Capacitor. Data (clients, follow-ups, etc.) is stored on the phone (localStorage).
WhatsApp sending needs the Node backend (`server.ts`), so deploy it somewhere with HTTPS (Cloud Run, Render, Railway...) and set the
WhatsApp env vars there.

## Option A: No Android Studio (GitHub Actions)
1. Create a GitHub repo and push this folder to the `main` branch.
2. Repo Settings > Secrets and variables > Actions > Variables > add `VITE_API_BASE` = your deployed server URL (https://...).
3. Actions tab > "Build Android APK" > Run workflow.
4. Download `HM-Client-Manager-APK` artifact > unzip > install `app-debug.apk` on your phone.

## Option B: Android Studio on your PC
1. Install Node 22, JDK 21 and Android Studio.
2. Create `.env.local` with `VITE_API_BASE=https://your-server-url`
3. Run:
   npm install
   npm run build
   npx cap add android
   npx cap sync android
   npx cap open android
4. In Android Studio: Build > Build APK(s). (For Play Store use Build > Generate Signed Bundle / APK.)
