import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.hmgroup.clientmanager',
  appName: 'HM Client Manager',
  webDir: 'dist',
  android: { allowMixedContent: false },
};

export default config;
