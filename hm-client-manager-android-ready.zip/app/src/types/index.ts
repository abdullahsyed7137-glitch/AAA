export type UserRole = 'Super Admin' | 'Manager' | 'Sales Executive';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone: string;
}

export type LeadStatus =
  | 'New Lead'
  | 'Contacted'
  | 'Interested'
  | 'Site Visit Scheduled'
  | 'Site Visit Completed'
  | 'Negotiation'
  | 'Booking Completed'
  | 'Lost/Inactive';

export type ConsentStatus = 'Opted-in' | 'Opted-out' | 'Pending';

export interface Client {
  id: string; // e.g. "HM-2025-0101"
  name: string;
  mobile: string;
  whatsappNumber: string;
  city: string;
  propertyInterest: string;
  projectName: string;
  budget: string;
  leadSource: string;
  leadStatus: LeadStatus;
  assignedExecutive: string;
  lastContactDate: string; // YYYY-MM-DD
  nextFollowUpDate: string; // YYYY-MM-DD
  notes: string;
  whatsappConsent: ConsentStatus;
  archived?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface FollowUp {
  id: string;
  clientId: string;
  clientName: string;
  clientMobile: string;
  assignedExecutive: string;
  dueDate: string; // YYYY-MM-DD
  dueTime: string; // HH:mm
  type: 'Call' | 'Site Visit' | 'Meeting' | 'WhatsApp Reminder';
  status: 'Pending' | 'Completed' | 'Overdue' | 'Cancelled';
  projectName: string;
  notes: string;
  completedAt?: string;
  outcome?: string;
}

export interface SiteVisit {
  id: string;
  clientId: string;
  clientName: string;
  clientMobile: string;
  projectName: string;
  propertyInterest: string;
  visitDate: string; // YYYY-MM-DD
  visitTime: string;
  assignedExecutive: string;
  status: 'Scheduled' | 'Completed' | 'Rescheduled' | 'No Show';
  feedback: string;
  rating?: number;
}

export interface WhatsAppTemplate {
  id: string;
  name: string;
  category: 'MARKETING' | 'UTILITY';
  language: 'en_US' | 'hi_IN';
  status: 'APPROVED' | 'PENDING' | 'REJECTED';
  headerType: 'NONE' | 'TEXT' | 'IMAGE' | 'DOCUMENT';
  headerText?: string;
  body: string;
  exampleVariables: string[];
  footer?: string;
  buttons?: {
    type: 'QUICK_REPLY' | 'URL' | 'PHONE_NUMBER';
    text: string;
    value?: string;
  }[];
}

export interface CampaignRecipientLog {
  clientId: string;
  clientName: string;
  whatsappNumber: string;
  status: 'Accepted' | 'Delivered' | 'Read' | 'Failed' | 'Opted-Out';
  wamid?: string;
  sentAt?: string;
  deliveredAt?: string;
  readAt?: string;
  errorCode?: string;
  errorMessage?: string;
}

export interface WhatsAppCampaign {
  id: string;
  name: string;
  createdAt: string;
  scheduledFor?: string;
  sentAt?: string;
  status: 'Draft' | 'Scheduled' | 'Processing' | 'Completed' | 'Failed';
  messageType: 'Template' | 'Custom';
  templateId?: string;
  messageBody: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'document';
  mediaName?: string;
  targetSegmentDescription: string;
  totalAudience: number;
  eligibleCount: number;
  optedOutExcluded: number;
  invalidExcluded: number;
  acceptedByApi: number;
  deliveredCount: number;
  readCount: number;
  failedCount: number;
  recipients: CampaignRecipientLog[];
  notes?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  user: string;
  role: UserRole;
  action:
    | 'IMPORT'
    | 'EXPORT'
    | 'CAMPAIGN_LAUNCH'
    | 'CLIENT_CREATE'
    | 'CLIENT_UPDATE'
    | 'CLIENT_DELETE'
    | 'OPT_OUT'
    | 'TEMPLATE_CREATE'
    | 'FOLLOWUP_UPDATE';
  details: string;
}

export interface WhatsAppConfig {
  phoneNumberId: string;
  businessAccountId: string;
  hasToken: boolean;
  webhookVerifyToken: string;
  isConfigured: boolean;
}
