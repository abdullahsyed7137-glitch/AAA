import React, { useState, useRef } from 'react';
import {
  X,
  Upload,
  FileSpreadsheet,
  AlertTriangle,
  CheckCircle2,
  FileText,
  Download,
} from 'lucide-react';
import { useCrm } from '../context/CrmContext';
import { parseExcelOrCsvFile, ImportPreviewResult, exportClientsToExcel } from '../utils/excelHelper';
import { DuplicateResolutionModal } from './DuplicateResolutionModal';

interface ExcelImportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExcelImportModal: React.FC<ExcelImportModalProps> = ({ isOpen, onClose }) => {
  const { clients, importClientsWithDuplicates } = useCrm();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [parsing, setParsing] = useState(false);
  const [parseResult, setParseResult] = useState<ImportPreviewResult | null>(null);
  const [showDuplicateModal, setShowDuplicateModal] = useState(false);

  if (!isOpen) return null;

  const handleFileChange = async (file: File) => {
    setSelectedFile(file);
    setParsing(true);
    try {
      const res = await parseExcelOrCsvFile(file, clients);
      setParseResult(res);
    } catch (err: any) {
      alert('Error parsing Excel/CSV file: ' + err.message);
    } finally {
      setParsing(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileChange(e.dataTransfer.files[0]);
    }
  };

  const handleComplete = () => {
    if (!parseResult) return;

    if (parseResult.duplicateClients.length > 0) {
      setShowDuplicateModal(true);
    } else {
      // Direct import since no duplicates
      importClientsWithDuplicates(parseResult.validClients, 'skip', []);
      onClose();
    }
  };

  const handleDuplicateResolved = (action: 'skip' | 'overwrite' | 'merge') => {
    if (!parseResult) return;
    importClientsWithDuplicates(parseResult.validClients, action, parseResult.duplicateClients);
    setShowDuplicateModal(false);
    onClose();
  };

  const downloadSampleTemplate = () => {
    const sampleData = [
      {
        id: 'SAMPLE-001',
        name: 'Sunil Rastogi',
        mobile: '9839099888',
        whatsappNumber: '9839099888',
        city: 'Lucknow',
        propertyInterest: '3 BHK Premium Flat',
        projectName: 'HM Royal Palms',
        budget: '₹75L - ₹1.2 Cr',
        leadSource: 'MagicBricks',
        leadStatus: 'Interested' as const,
        assignedExecutive: 'Tariq Ansari',
        lastContactDate: '2025-05-19',
        nextFollowUpDate: '2025-05-24',
        notes: 'Inquired about Tower C corner facing 3BHK',
        whatsappConsent: 'Opted-in' as const,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ];
    exportClientsToExcel(sampleData as any, 'HM_Client_Import_Template.xlsx');
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
        <div className="relative w-full max-w-xl rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-slate-100 bg-slate-900 px-6 py-4 text-white">
            <div className="flex items-center gap-2.5">
              <FileSpreadsheet className="h-5 w-5 text-emerald-400" />
              <h3 className="font-bold text-base">Import Clients from Excel or CSV</h3>
            </div>
            <button
              onClick={onClose}
              className="rounded-lg p-1 text-slate-300 hover:bg-slate-800 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="p-6 space-y-4">
            <div className="flex items-center justify-between text-xs text-slate-600">
              <p>Upload an existing Excel (.xlsx, .xls) or CSV list of real estate leads.</p>
              <button
                onClick={downloadSampleTemplate}
                className="flex items-center gap-1 font-semibold text-emerald-700 hover:text-emerald-800"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Download Sample Sheet</span>
              </button>
            </div>

            {/* Drop Zone */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`flex flex-col items-center justify-center rounded-xl border-2 border-dashed p-6 text-center cursor-pointer transition-colors ${
                isDragging
                  ? 'border-emerald-600 bg-emerald-50/50'
                  : 'border-slate-300 hover:border-emerald-500 bg-slate-50'
              }`}
            >
              <Upload className="h-8 w-8 text-slate-400 mb-2" />
              <p className="text-xs font-semibold text-slate-700">
                Click to browse or drag and drop your spreadsheet here
              </p>
              <p className="text-[11px] text-slate-500 mt-1">
                Supports Excel (.xlsx, .xls) and CSV files
              </p>
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileChange(e.target.files[0]);
                  }
                }}
              />
            </div>

            {/* Parsing State */}
            {parsing && (
              <div className="flex items-center justify-center py-4 text-xs font-semibold text-emerald-700 gap-2">
                <div className="h-4 w-4 animate-spin rounded-full border-2 border-emerald-600 border-t-transparent" />
                <span>Reading and validating rows...</span>
              </div>
            )}

            {/* Parsed Summary Card */}
            {parseResult && !parsing && (
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <span className="text-xs font-bold text-slate-800">
                    File: {selectedFile?.name}
                  </span>
                  <span className="text-xs text-slate-600">
                    Total Rows: <strong>{parseResult.totalRows}</strong>
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="rounded-lg bg-emerald-100 p-2 text-emerald-900 border border-emerald-200 font-medium">
                    <span className="block text-base font-bold">{parseResult.validClients.length}</span>
                    <span>Ready to Add</span>
                  </div>
                  <div className="rounded-lg bg-amber-100 p-2 text-amber-900 border border-amber-200 font-medium">
                    <span className="block text-base font-bold">
                      {parseResult.duplicateClients.length}
                    </span>
                    <span>Duplicates</span>
                  </div>
                  <div className="rounded-lg bg-rose-100 p-2 text-rose-900 border border-rose-200 font-medium">
                    <span className="block text-base font-bold">
                      {parseResult.invalidClients.length}
                    </span>
                    <span>Invalid Rows</span>
                  </div>
                </div>

                {parseResult.invalidClients.length > 0 && (
                  <div className="rounded-lg bg-rose-50 border border-rose-200 p-2.5 text-[11px] text-rose-700 max-h-24 overflow-y-auto">
                    <div className="font-semibold mb-1">Skipping invalid rows:</div>
                    {parseResult.invalidClients.map((inv, idx) => (
                      <div key={idx}>• {inv.reason}</div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={onClose}
                className="rounded-lg border border-slate-300 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={!parseResult || (parseResult.validClients.length === 0 && parseResult.duplicateClients.length === 0)}
                onClick={handleComplete}
                className="rounded-lg bg-emerald-800 px-5 py-2 text-xs font-semibold text-white shadow-sm hover:bg-emerald-900 disabled:opacity-50 transition-colors flex items-center gap-1.5"
              >
                <CheckCircle2 className="h-4 w-4" />
                <span>
                  {parseResult?.duplicateClients.length
                    ? 'Review & Resolve Duplicates'
                    : 'Import Verified Clients'}
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Duplicate confirmation modal */}
      {showDuplicateModal && parseResult && (
        <DuplicateResolutionModal
          isOpen={showDuplicateModal}
          onClose={() => setShowDuplicateModal(false)}
          validCount={parseResult.validClients.length}
          duplicates={parseResult.duplicateClients}
          onConfirm={handleDuplicateResolved}
        />
      )}
    </>
  );
};
