import { API_BASE } from '../utils/api';
import React, { useState } from 'react';
import {
  X,
  MessageSquare,
  Key,
  Shield,
  CheckCircle2,
  AlertTriangle,
  Send,
  ExternalLink,
  Copy,
  Check,
  HelpCircle,
  Server,
  FileCode,
} from 'lucide-react';
import { useCrm } from '../context/CrmContext';

interface WhatsAppSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WhatsAppSettingsModal: React.FC<WhatsAppSettingsModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { apiConfig, refreshApiStatus } = useCrm();

  const [testNumber, setTestNumber] = useState('9839012345');
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [testing, setTesting] = useState(false);
  const [copiedWebhook, setCopiedWebhook] = useState(false);

  if (!isOpen) return null;

  const webhookUrl = `${window.location.origin}/api/whatsapp/webhook`;

  const handleCopyWebhook = () => {
    navigator.clipboard.writeText(webhookUrl);
    setCopiedWebhook(true);
    setTimeout(() => setCopiedWebhook(false), 2000);
  };

  const handleSendTestMessage = async () => {
    setTesting(true);
    setTestResult(null);

    try {
      const res = await fetch(`${API_BASE}/api/whatsapp/send`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to: testNumber,
          type: 'text',
          text: 'Namaste from HM Group Lucknow! This is a test message from your CRM via Meta WhatsApp Business Cloud API.',
          recipientName: 'HM Admin Test',
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setTestResult({
          success: true,
          message: `Test message accepted by Meta Cloud API! Message ID: ${data.messageId}`,
        });
      } else {
        setTestResult({
          success: false,
          message: data.error || 'WhatsApp API request failed',
        });
      }
    } catch (err: any) {
      setTestResult({
        success: false,
        message: err.message || 'Connection error to backend proxy',
      });
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 bg-emerald-950 px-6 py-4 text-white">
          <div className="flex items-center gap-2.5">
            <MessageSquare className="h-5 w-5 text-amber-300" />
            <div>
              <h3 className="font-bold text-base">Meta WhatsApp Business Cloud API Settings</h3>
              <p className="text-[11px] text-emerald-200">
                Official Graph API v19.0 Integration for HM Group of Companies
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-slate-300 hover:bg-emerald-900 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-6 space-y-5 text-xs max-h-[80vh] overflow-y-auto">
          {/* Status Alert Banner */}
          <div
            className={`rounded-xl border p-4 ${
              apiConfig.isConfigured
                ? 'border-emerald-300 bg-emerald-50 text-emerald-900'
                : 'border-amber-300 bg-amber-50 text-amber-900'
            }`}
          >
            <div className="flex items-start gap-3">
              {apiConfig.isConfigured ? (
                <CheckCircle2 className="h-5 w-5 text-emerald-700 shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="h-5 w-5 text-amber-700 shrink-0 mt-0.5" />
              )}
              <div className="space-y-1">
                <h4 className="font-bold text-sm">
                  {apiConfig.isConfigured
                    ? 'Official WhatsApp Cloud API Ready'
                    : 'WhatsApp Cloud API Setup Required'}
                </h4>
                <p className="text-[11px]">
                  {apiConfig.isConfigured
                    ? 'Your backend has valid WhatsApp credentials configured. Broadcast campaigns and template dispatches are fully active.'
                    : 'Backend credentials (WHATSAPP_ACCESS_TOKEN and WHATSAPP_PHONE_NUMBER_ID) are not configured. Messages will not simulate delivery; configure your Meta Developer credentials to send live campaigns.'}
                </p>
              </div>
            </div>
          </div>

          {/* Current Backend Configuration Summary */}
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-3">
            <h4 className="font-bold text-xs text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Server className="h-4 w-4 text-slate-600" />
              <span>Current Backend API Environment Status</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="rounded-lg bg-white border border-slate-200 p-2.5">
                <span className="text-slate-500 block text-[11px]">Phone Number ID:</span>
                <span className="font-mono font-bold text-slate-900">
                  {apiConfig.phoneNumberId || 'Not Configured'}
                </span>
              </div>

              <div className="rounded-lg bg-white border border-slate-200 p-2.5">
                <span className="text-slate-500 block text-[11px]">WABA Account ID:</span>
                <span className="font-mono font-bold text-slate-900">
                  {apiConfig.businessAccountId || 'Not Configured'}
                </span>
              </div>

              <div className="rounded-lg bg-white border border-slate-200 p-2.5">
                <span className="text-slate-500 block text-[11px]">Meta Access Token:</span>
                <span className="font-mono font-bold text-slate-900">
                  {apiConfig.hasToken ? '•••••••••••••••• (Encrypted in Backend)' : 'Missing'}
                </span>
              </div>

              <div className="rounded-lg bg-white border border-slate-200 p-2.5">
                <span className="text-slate-500 block text-[11px]">Webhook Verification Token:</span>
                <span className="font-mono font-bold text-emerald-800">
                  {apiConfig.webhookVerifyToken}
                </span>
              </div>
            </div>
          </div>

          {/* Webhook Configuration for Meta Developer Portal */}
          <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
            <h4 className="font-bold text-xs text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Key className="h-4 w-4 text-emerald-700" />
              <span>Meta Webhook Configuration (Delivery Receipts & Opt-Outs)</span>
            </h4>

            <div className="space-y-2">
              <label className="text-[11px] font-semibold text-slate-700">Webhook Callback URL</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  readOnly
                  value={webhookUrl}
                  className="flex-1 rounded-lg border border-slate-300 bg-slate-50 px-3 py-1.5 font-mono text-[11px] text-slate-800"
                />
                <button
                  onClick={handleCopyWebhook}
                  className="flex items-center gap-1 rounded-lg bg-slate-100 hover:bg-slate-200 px-3 py-1.5 font-semibold text-slate-700 transition-colors"
                >
                  {copiedWebhook ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>{copiedWebhook ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <p className="text-[11px] text-slate-500">
                In Meta App Dashboard → WhatsApp → Configuration → Callback URL, enter this URL and set Verify Token to <code className="font-mono font-bold">{apiConfig.webhookVerifyToken}</code>. Subscribe to <code className="font-mono">messages</code>.
              </p>
            </div>
          </div>

          {/* Test Message Tool */}
          <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
            <h4 className="font-bold text-xs text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Send className="h-4 w-4 text-emerald-700" />
              <span>Test Official WhatsApp API Connection</span>
            </h4>

            <div className="flex flex-col sm:flex-row gap-2">
              <div className="flex-1 relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-medium text-slate-400">
                  +91
                </span>
                <input
                  type="tel"
                  value={testNumber}
                  onChange={(e) => setTestNumber(e.target.value)}
                  placeholder="Enter 10-digit Indian test mobile..."
                  className="w-full rounded-lg border border-slate-300 pl-10 pr-3 py-2 text-xs focus:border-emerald-600 focus:outline-none"
                />
              </div>

              <button
                onClick={handleSendTestMessage}
                disabled={testing || !testNumber}
                className="rounded-lg bg-emerald-800 hover:bg-emerald-900 px-4 py-2 font-semibold text-white shadow-xs disabled:opacity-50 flex items-center justify-center gap-1.5"
              >
                {testing ? (
                  <div className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-white border-t-transparent" />
                ) : (
                  <Send className="h-3.5 w-3.5" />
                )}
                <span>Send API Test Message</span>
              </button>
            </div>

            {testResult && (
              <div
                className={`p-3 rounded-lg border text-xs ${
                  testResult.success
                    ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
                    : 'border-rose-200 bg-rose-50 text-rose-900'
                }`}
              >
                {testResult.message}
              </div>
            )}
          </div>

          {/* Step-by-Step Meta Cloud API Setup Guide for HM Group */}
          <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
            <h4 className="font-bold text-xs text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <HelpCircle className="h-4 w-4 text-emerald-700" />
              <span>Step-by-Step Official Setup Guide (HM Group Lucknow)</span>
            </h4>

            <ol className="list-decimal list-inside space-y-2 text-slate-600 text-[11px] leading-relaxed">
              <li>
                Visit <strong>developers.facebook.com</strong> and create a Business App under your HM Group Meta account.
              </li>
              <li>
                Add the <strong>WhatsApp</strong> product to your app.
              </li>
              <li>
                In the WhatsApp API Setup panel, copy your <strong>Phone Number ID</strong> and <strong>WhatsApp Business Account ID</strong>.
              </li>
              <li>
                Generate a <strong>Permanent System User Access Token</strong> in Meta Business Settings (with <code className="font-mono">whatsapp_business_messaging</code> and <code className="font-mono">whatsapp_business_management</code> permissions).
              </li>
              <li>
                Add these variables to your production environment (<code className="font-mono">.env</code>):
                <pre className="mt-1 rounded bg-slate-900 text-emerald-400 p-2 font-mono text-[10px]">
{`WHATSAPP_PHONE_NUMBER_ID="your_phone_number_id"
WHATSAPP_BUSINESS_ACCOUNT_ID="your_waba_id"
WHATSAPP_ACCESS_TOKEN="EAAB..."
WHATSAPP_WEBHOOK_VERIFY_TOKEN="hm_group_lucknow_crm_2025"`}
                </pre>
              </li>
              <li>
                Submit templates in Meta Business Manager under Message Templates (category: MARKETING / UTILITY). Once approved, they sync directly into HM Client Manager.
              </li>
            </ol>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between border-t border-slate-100 bg-slate-50 px-6 py-3">
          <span className="text-[11px] text-slate-500 font-mono">
            HM Group Lucknow • Official API v19.0
          </span>
          <button
            onClick={onClose}
            className="rounded-lg bg-emerald-800 px-4 py-1.5 text-xs font-semibold text-white hover:bg-emerald-900"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
