import React, { useState } from 'react';
import { AlertTriangle, Check, ShieldCheck, ArrowRight, UserCheck, X } from 'lucide-react';
import { Client } from '../types';

interface DuplicateResolutionModalProps {
  isOpen: boolean;
  onClose: () => void;
  validCount: number;
  duplicates: Array<{
    candidate: Partial<Client>;
    existing: { id: string; name: string; mobile: string; whatsappNumber: string };
    matchField: 'mobile' | 'whatsappNumber';
  }>;
  onConfirm: (action: 'skip' | 'overwrite' | 'merge') => void;
}

export const DuplicateResolutionModal: React.FC<DuplicateResolutionModalProps> = ({
  isOpen,
  onClose,
  validCount,
  duplicates,
  onConfirm,
}) => {
  if (!isOpen) return null;

  const [selectedAction, setSelectedAction] = useState<'skip' | 'overwrite' | 'merge'>('skip');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
      <div className="relative w-full max-w-2xl rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-amber-200 bg-amber-500 px-6 py-4 text-slate-900">
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="h-5 w-5 text-slate-950" />
            <h3 className="font-bold text-base text-slate-950">
              Duplicate Client Numbers Detected ({duplicates.length})
            </h3>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-slate-900 hover:bg-amber-600/40 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          <p className="text-xs text-slate-600">
            HM Client Manager ensures strict data integrity. The uploaded Excel sheet contains{' '}
            <strong className="text-slate-900">{duplicates.length} client(s)</strong> whose mobile or
            WhatsApp numbers already exist in the CRM database.
          </p>

          <div className="rounded-lg bg-slate-50 border border-slate-200 p-3 text-xs">
            <span className="font-semibold text-emerald-800">
              ✓ {validCount} new unique client(s) will be added immediately.
            </span>
          </div>

          {/* Conflict List Preview */}
          <div className="max-h-48 overflow-y-auto rounded-lg border border-slate-200 divide-y divide-slate-100 text-xs">
            {duplicates.map((dup, idx) => (
              <div key={idx} className="p-2.5 flex items-center justify-between bg-white hover:bg-slate-50">
                <div>
                  <span className="font-semibold text-slate-900">{dup.candidate.name}</span>
                  <span className="text-slate-500 ml-1.5 text-[11px] font-mono">
                    ({dup.candidate.mobile})
                  </span>
                  <p className="text-[11px] text-slate-500">
                    Import: {dup.candidate.projectName} • {dup.candidate.propertyInterest}
                  </p>
                </div>
                <ArrowRight className="h-4 w-4 text-slate-400 shrink-0 mx-2" />
                <div className="text-right">
                  <span className="font-medium text-amber-800">Existing: {dup.existing.name}</span>
                  <p className="text-[10px] text-slate-500 font-mono">ID: {dup.existing.id}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Action Choice Selection */}
          <div className="space-y-2 pt-2">
            <label className="text-xs font-bold text-slate-800">
              Please choose how to handle conflicting duplicates:
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <button
                type="button"
                onClick={() => setSelectedAction('skip')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  selectedAction === 'skip'
                    ? 'border-emerald-600 bg-emerald-50/70 text-emerald-900 ring-2 ring-emerald-600'
                    : 'border-slate-200 bg-white hover:border-slate-300 text-slate-700'
                }`}
              >
                <div className="font-bold text-xs">1. Skip Duplicates</div>
                <p className="mt-1 text-[11px] text-slate-500">
                  (Recommended) Keep existing records intact; add only unique new clients.
                </p>
              </button>

              <button
                type="button"
                onClick={() => setSelectedAction('merge')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  selectedAction === 'merge'
                    ? 'border-emerald-600 bg-emerald-50/70 text-emerald-900 ring-2 ring-emerald-600'
                    : 'border-slate-200 bg-white hover:border-slate-300 text-slate-700'
                }`}
              >
                <div className="font-bold text-xs">2. Merge Data</div>
                <p className="mt-1 text-[11px] text-slate-500">
                  Keep existing records, append imported notes and fill empty fields.
                </p>
              </button>

              <button
                type="button"
                onClick={() => setSelectedAction('overwrite')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  selectedAction === 'overwrite'
                    ? 'border-rose-600 bg-rose-50/70 text-rose-900 ring-2 ring-rose-600'
                    : 'border-slate-200 bg-white hover:border-slate-300 text-slate-700'
                }`}
              >
                <div className="font-bold text-xs">3. Overwrite</div>
                <p className="mt-1 text-[11px] text-slate-500">
                  Replace existing matching clients with new data from the spreadsheet.
                </p>
              </button>
            </div>
          </div>

          {/* Modal Footer */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              onClick={onClose}
              className="rounded-lg border border-slate-300 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              Cancel Import
            </button>
            <button
              onClick={() => {
                onConfirm(selectedAction);
                onClose();
              }}
              className="rounded-lg bg-emerald-800 px-5 py-2 text-xs font-semibold text-white shadow-sm hover:bg-emerald-900 flex items-center gap-1.5"
            >
              <Check className="h-4 w-4" />
              <span>Confirm & Complete Import</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
