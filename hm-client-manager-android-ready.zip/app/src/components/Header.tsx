import React from 'react';
import {
  Building2,
  Search,
  Bell,
  Shield,
  MessageSquare,
  UserCheck,
  Plus,
  ExternalLink,
  AlertTriangle,
} from 'lucide-react';
import { useCrm } from '../context/CrmContext';
import { UserRole } from '../types';

interface HeaderProps {
  onOpenAddClient: () => void;
  onOpenSettings: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenAddClient, onOpenSettings }) => {
  const {
    currentRole,
    setCurrentRole,
    apiConfig,
    followUps,
    setActiveTab,
    searchQuery,
    setSearchQuery,
  } = useCrm();

  const overdueCount = followUps.filter((f) => f.status === 'Overdue').length;
  const pendingCount = followUps.filter((f) => f.status === 'Pending').length;

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-200 bg-white/95 px-4 backdrop-blur-md lg:px-6">
      {/* Brand & Location */}
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-800 text-amber-300 shadow-sm">
          <Building2 className="h-6 w-6" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-900 tracking-tight text-base sm:text-lg">
              HM GROUP OF COMPANIES
            </span>
            <span className="rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-semibold text-amber-800 border border-amber-200">
              LUCKNOW
            </span>
          </div>
          <p className="text-xs text-slate-500 hidden sm:block">
            Real Estate Client CRM & Official WhatsApp Cloud API Platform
          </p>
        </div>
      </div>

      {/* Global Search Bar */}
      <div className="hidden md:flex items-center flex-1 max-w-md mx-6">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search clients by name, mobile, project or budget..."
            className="w-full rounded-lg border border-slate-200 bg-slate-50 py-1.5 pl-9 pr-3 text-xs text-slate-800 focus:border-emerald-600 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-600"
          />
        </div>
      </div>

      {/* Right Controls: WhatsApp Status, Notifications, Role Switcher, Add Client */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* WhatsApp Cloud API Badge */}
        <button
          onClick={onOpenSettings}
          className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium border transition-colors ${
            apiConfig.isConfigured
              ? 'border-emerald-200 bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
              : 'border-amber-300 bg-amber-50 text-amber-800 hover:bg-amber-100'
          }`}
          title="Click to view WhatsApp Business Cloud API Configuration"
        >
          <MessageSquare className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">WhatsApp Cloud API:</span>
          <span className="font-semibold">
            {apiConfig.isConfigured ? 'Ready' : 'Setup Required'}
          </span>
          {!apiConfig.isConfigured && <AlertTriangle className="h-3 w-3 text-amber-600" />}
        </button>

        {/* Follow-up Reminder Bell */}
        <button
          onClick={() => setActiveTab('follow-ups')}
          className="relative rounded-lg p-2 text-slate-600 hover:bg-slate-100 transition-colors"
          title={`${overdueCount} overdue, ${pendingCount} pending follow-ups`}
        >
          <Bell className="h-5 w-5" />
          {overdueCount > 0 ? (
            <span className="absolute -top-1 -right-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-600 px-1 text-[10px] font-bold text-white">
              {overdueCount}
            </span>
          ) : pendingCount > 0 ? (
            <span className="absolute -top-1 -right-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-amber-500 px-1 text-[10px] font-bold text-white">
              {pendingCount}
            </span>
          ) : null}
        </button>

        {/* Role Selector (RBAC demonstration & permission switching) */}
        <div className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-2 py-1">
          <Shield className="h-3.5 w-3.5 text-slate-500 hidden sm:block" />
          <select
            value={currentRole}
            onChange={(e) => setCurrentRole(e.target.value as UserRole)}
            className="bg-transparent text-xs font-semibold text-slate-700 focus:outline-none cursor-pointer"
            aria-label="Active Security Role"
          >
            <option value="Super Admin">Super Admin (Director)</option>
            <option value="Manager">Manager (Sales Head)</option>
            <option value="Sales Executive">Sales Executive</option>
          </select>
        </div>

        {/* Quick Add Client Button */}
        <button
          onClick={onOpenAddClient}
          className="flex items-center gap-1.5 rounded-lg bg-emerald-800 px-3 py-1.5 text-xs font-medium text-white shadow-sm hover:bg-emerald-900 transition-colors"
        >
          <Plus className="h-4 w-4" />
          <span className="hidden sm:inline">Add Client</span>
        </button>
      </div>
    </header>
  );
};
