import React, { useState } from 'react';
import {
  FileText,
  Plus,
  CheckCircle2,
  Clock,
  Sparkles,
  MessageSquare,
  X,
  Send,
  Eye,
  ShieldCheck,
} from 'lucide-react';
import { useCrm } from '../context/CrmContext';
import { WhatsAppTemplate } from '../types';

export const TemplateManagementView: React.FC = () => {
  const { templates, addTemplate, setActiveTab } = useCrm();
  const [showAddModal, setShowAddModal] = useState(false);

  // Form states
  const [name, setName] = useState('');
  const [category, setCategory] = useState<'MARKETING' | 'UTILITY'>('MARKETING');
  const [language, setLanguage] = useState<'en_US' | 'hi_IN'>('en_US');
  const [headerType, setHeaderType] = useState<'NONE' | 'TEXT' | 'IMAGE' | 'DOCUMENT'>('IMAGE');
  const [body, setBody] = useState('');
  const [footer, setFooter] = useState('Reply STOP to unsubscribe from HM Group alerts');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !body.trim()) return;

    addTemplate({
      name: name.toLowerCase().replace(/[^a-z0-9_]/g, '_'),
      category,
      language,
      status: 'APPROVED',
      headerType,
      body,
      exampleVariables: ['Client Name', 'HM Project', 'Executive Name'],
      footer,
      buttons: [{ type: 'QUICK_REPLY', text: 'Interested' }],
    });

    setShowAddModal(false);
    setName('');
    setBody('');
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <FileText className="h-5 w-5 text-emerald-800" />
            <span>WhatsApp Business Approved Message Templates</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Meta Cloud API pre-approved templates with variable mapping for automated customer notifications.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 px-3.5 py-1.5 text-xs font-semibold text-white shadow-xs self-start sm:self-auto"
        >
          <Plus className="h-3.5 w-3.5" />
          <span>Register New Template</span>
        </button>
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {templates.map((tpl) => (
          <div
            key={tpl.id}
            className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs flex flex-col justify-between space-y-3"
          >
            <div>
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-bold text-xs text-slate-900 font-mono">{tpl.name}</h3>
                  <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-0.5">
                    <span className="rounded bg-slate-100 px-1.5 py-0.2 font-semibold">
                      {tpl.category}
                    </span>
                    <span>•</span>
                    <span>{tpl.language === 'en_US' ? 'English (US)' : 'Hindi (India)'}</span>
                    <span>•</span>
                    <span>Header: {tpl.headerType}</span>
                  </div>
                </div>

                <span className="flex items-center gap-1 rounded bg-emerald-100 text-emerald-900 px-2 py-0.5 text-[10px] font-bold">
                  <CheckCircle2 className="h-3 w-3 text-emerald-700" />
                  <span>{tpl.status}</span>
                </span>
              </div>

              {/* Template Body Preview */}
              <div className="mt-3 rounded-lg bg-slate-50 border border-slate-200 p-3 text-xs text-slate-800 whitespace-pre-wrap font-sans leading-relaxed">
                {tpl.body}
              </div>

              {tpl.footer && (
                <div className="mt-2 text-[10px] text-slate-400 italic">Footer: {tpl.footer}</div>
              )}

              {/* Buttons */}
              {tpl.buttons && tpl.buttons.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1.5 pt-2 border-t border-slate-100">
                  {tpl.buttons.map((b, i) => (
                    <span
                      key={i}
                      className="rounded border border-emerald-300 bg-emerald-50 px-2 py-0.5 text-[10px] font-semibold text-emerald-800"
                    >
                      [{b.type}] {b.text}
                    </span>
                  ))}
                </div>
              )}
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
              <span className="text-[11px] text-slate-400 font-mono">ID: {tpl.id}</span>
              <button
                onClick={() => setActiveTab('campaign-builder')}
                className="flex items-center gap-1 font-semibold text-emerald-700 hover:text-emerald-800"
              >
                <Send className="h-3 w-3" />
                <span>Use in Campaign</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add Template Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-lg rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between border-b border-slate-100 bg-emerald-950 px-5 py-4 text-white">
              <h3 className="font-bold text-sm">Register Meta WhatsApp Message Template</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-300 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="p-5 space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Template Name (lowercase with underscores) *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. hm_site_visit_reminder"
                  className="w-full rounded border border-slate-300 p-2 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full rounded border border-slate-300 p-2"
                  >
                    <option value="MARKETING">MARKETING</option>
                    <option value="UTILITY">UTILITY</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Language</label>
                  <select
                    value={language}
                    onChange={(e) => setLanguage(e.target.value as any)}
                    className="w-full rounded border border-slate-300 p-2"
                  >
                    <option value="en_US">English (en_US)</option>
                    <option value="hi_IN">Hindi (hi_IN)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Header Media Type</label>
                <select
                  value={headerType}
                  onChange={(e) => setHeaderType(e.target.value as any)}
                  className="w-full rounded border border-slate-300 p-2"
                >
                  <option value="NONE">None (Text Only)</option>
                  <option value="IMAGE">Image Poster</option>
                  <option value="DOCUMENT">PDF Document</option>
                  <option value="TEXT">Short Text Header</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Message Body (Use {'{{1}}'}, {'{{2}}'} for variables) *
                </label>
                <textarea
                  rows={4}
                  required
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                  placeholder="Dear {{1}}, welcome to {{2}} in Lucknow..."
                  className="w-full rounded border border-slate-300 p-2"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Footer Disclaimer</label>
                <input
                  type="text"
                  value={footer}
                  onChange={(e) => setFooter(e.target.value)}
                  className="w-full rounded border border-slate-300 p-2"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="rounded border border-slate-300 px-3 py-1.5 text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded bg-emerald-800 text-white px-4 py-1.5 font-semibold hover:bg-emerald-900"
                >
                  Submit Template
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
