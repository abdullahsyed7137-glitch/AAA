import React, { useState } from 'react';
import {
  BarChart3,
  Calendar,
  CheckCircle,
  Eye,
  AlertCircle,
  Clock,
  Send,
  X,
  FileText,
  ShieldCheck,
  CheckCircle2,
  ExternalLink,
  Info,
} from 'lucide-react';
import { useCrm } from '../context/CrmContext';
import { WhatsAppCampaign, CampaignRecipientLog } from '../types';

export const CampaignReportsView: React.FC = () => {
  const { campaigns, setActiveTab } = useCrm();
  const [selectedCampaign, setSelectedCampaign] = useState<WhatsAppCampaign | null>(
    campaigns[0] || null
  );

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-emerald-800" />
            <span>Official WhatsApp Campaign Reports & Analytics</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time delivery receipts, read statuses, and failure diagnostic reports via Meta Cloud API webhooks.
          </p>
        </div>

        <button
          onClick={() => setActiveTab('campaign-builder')}
          className="flex items-center gap-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 px-3.5 py-1.5 text-xs font-semibold text-white shadow-xs self-start sm:self-auto"
        >
          <Send className="h-3.5 w-3.5" />
          <span>New Campaign</span>
        </button>
      </div>

      {/* Critical Clarification Banner: API Acceptance vs Delivery */}
      <div className="rounded-xl border border-blue-200 bg-blue-50/70 p-4 text-xs text-blue-900">
        <div className="flex items-start gap-2.5">
          <Info className="h-4 w-4 text-blue-700 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <strong className="block font-semibold">
              Distinction: Meta API Acceptance vs Confirmed Delivery
            </strong>
            <p className="text-[11px] text-blue-800 leading-relaxed">
              <strong>API Acceptance:</strong> Indicates that Meta's WhatsApp Cloud API has successfully validated the payload, verified template compliance, and scheduled the message with a unique message ID (<code className="font-mono">wamid...</code>).<br />
              <strong>Confirmed Delivery:</strong> Occurs when the recipient's physical device acknowledges receipt over the network (double grey tick) or read receipt (blue tick).
            </p>
          </div>
        </div>
      </div>

      {/* Campaigns Table */}
      <div className="rounded-xl border border-slate-200 bg-white shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            All WhatsApp Campaigns ({campaigns.length})
          </h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Campaign Name & Type</th>
                <th className="py-3 px-3">Date Dispatched</th>
                <th className="py-3 px-3 text-center">Intended</th>
                <th className="py-3 px-3 text-center">API Accepted</th>
                <th className="py-3 px-3 text-center">Delivered</th>
                <th className="py-3 px-3 text-center">Read</th>
                <th className="py-3 px-3 text-center">Failed</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-4 text-right">Drilldown</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {campaigns.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-10 text-center text-slate-400">
                    No WhatsApp campaigns launched yet.
                  </td>
                </tr>
              ) : (
                campaigns.map((cmp) => {
                  const deliveryPct = cmp.acceptedByApi > 0 ? Math.round((cmp.deliveredCount / cmp.acceptedByApi) * 100) : 0;
                  const isSelected = selectedCampaign?.id === cmp.id;

                  return (
                    <tr
                      key={cmp.id}
                      className={`hover:bg-slate-50 transition-colors ${
                        isSelected ? 'bg-emerald-50/40' : ''
                      }`}
                    >
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900">{cmp.name}</div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          {cmp.id} • {cmp.messageType}
                        </div>
                      </td>

                      <td className="py-3 px-3 text-slate-600">
                        {cmp.sentAt ? new Date(cmp.sentAt).toLocaleString('en-IN', {
                          dateStyle: 'medium',
                          timeStyle: 'short',
                        }) : cmp.scheduledFor ? `Scheduled: ${cmp.scheduledFor}` : 'Draft'}
                      </td>

                      <td className="py-3 px-3 text-center font-semibold text-slate-800">
                        {cmp.totalAudience}
                      </td>

                      <td className="py-3 px-3 text-center font-bold text-emerald-800 bg-emerald-50/50">
                        {cmp.acceptedByApi}
                      </td>

                      <td className="py-3 px-3 text-center font-semibold text-teal-800">
                        {cmp.deliveredCount}
                        {cmp.acceptedByApi > 0 && (
                          <span className="block text-[10px] text-teal-600 font-normal">
                            {deliveryPct}%
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-3 text-center font-semibold text-indigo-800">
                        {cmp.readCount}
                      </td>

                      <td className="py-3 px-3 text-center font-bold text-rose-700">
                        {cmp.failedCount > 0 ? (
                          <span className="rounded bg-rose-100 px-1.5 py-0.5 text-[10px]">
                            {cmp.failedCount}
                          </span>
                        ) : (
                          '0'
                        )}
                      </td>

                      <td className="py-3 px-3">
                        <span
                          className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                            cmp.status === 'Completed'
                              ? 'bg-emerald-100 text-emerald-800'
                              : cmp.status === 'Processing'
                              ? 'bg-amber-100 text-amber-800'
                              : cmp.status === 'Scheduled'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {cmp.status}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => setSelectedCampaign(cmp)}
                          className="rounded-lg border border-slate-300 bg-white px-2.5 py-1 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
                        >
                          View Logs
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Selected Campaign Detailed Recipient Logs */}
      {selectedCampaign && (
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs text-emerald-800 font-bold">
                  {selectedCampaign.id}
                </span>
                <span className="text-xs text-slate-400">•</span>
                <h3 className="font-bold text-sm text-slate-900">{selectedCampaign.name}</h3>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Target: {selectedCampaign.targetSegmentDescription}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="rounded bg-emerald-100 text-emerald-900 px-2 py-0.5 text-[11px] font-bold">
                {selectedCampaign.acceptedByApi} API Accepted
              </span>
              <span className="rounded bg-teal-100 text-teal-900 px-2 py-0.5 text-[11px] font-bold">
                {selectedCampaign.deliveredCount} Delivered
              </span>
              <span className="rounded bg-indigo-100 text-indigo-900 px-2 py-0.5 text-[11px] font-bold">
                {selectedCampaign.readCount} Read
              </span>
            </div>
          </div>

          {/* Recipient Level Status Table */}
          <div>
            <h4 className="text-xs font-bold text-slate-800 mb-2">
              Per-Recipient Meta Delivery Status Log ({selectedCampaign.recipients.length})
            </h4>

            <div className="rounded-lg border border-slate-200 overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold text-[11px]">
                  <tr>
                    <th className="py-2.5 px-3">Client</th>
                    <th className="py-2.5 px-3">WhatsApp Number</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">Meta Message ID (wamid)</th>
                    <th className="py-2.5 px-3">Delivery Timestamps</th>
                    <th className="py-2.5 px-3">Error / Opt-out Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {selectedCampaign.recipients.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-6 text-center text-slate-400">
                        No recipient logs recorded for this campaign draft.
                      </td>
                    </tr>
                  ) : (
                    selectedCampaign.recipients.map((r, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="py-2 px-3 font-semibold text-slate-900">{r.clientName}</td>
                        <td className="py-2 px-3 font-mono text-slate-600">{r.whatsappNumber}</td>
                        <td className="py-2 px-3">
                          <span
                            className={`rounded px-2 py-0.5 text-[10px] font-bold ${
                              r.status === 'Read'
                                ? 'bg-indigo-100 text-indigo-800'
                                : r.status === 'Delivered'
                                ? 'bg-teal-100 text-teal-800'
                                : r.status === 'Accepted'
                                ? 'bg-emerald-100 text-emerald-800'
                                : r.status === 'Opted-Out'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {r.status}
                          </span>
                        </td>
                        <td className="py-2 px-3 font-mono text-[11px] text-slate-500 truncate max-w-xs">
                          {r.wamid || '—'}
                        </td>
                        <td className="py-2 px-3 text-[11px] text-slate-500">
                          {r.readAt
                            ? `Read: ${r.readAt}`
                            : r.deliveredAt
                            ? `Delivered: ${r.deliveredAt}`
                            : r.sentAt
                            ? `Accepted: ${r.sentAt}`
                            : '—'}
                        </td>
                        <td className="py-2 px-3 text-[11px] text-rose-700">
                          {r.errorMessage || (r.status === 'Opted-Out' ? 'Consent Opted-out' : '—')}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
