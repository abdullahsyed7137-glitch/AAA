import React from 'react';
import {
  Users,
  UserPlus,
  HeartHandshake,
  CalendarCheck,
  CheckCircle,
  Clock,
  Send,
  BarChart,
  TrendingUp,
  MapPin,
  ArrowUpRight,
  ShieldAlert,
  Building,
  PhoneCall,
} from 'lucide-react';
import { useCrm } from '../context/CrmContext';
import { LUCKNOW_PROJECTS } from '../data/seedData';
import { calculateCampaignStats } from '../utils/whatsappHelper';

interface DashboardViewProps {
  onOpenAddClient: () => void;
  onOpenImport: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onOpenAddClient, onOpenImport }) => {
  const { clients, followUps, siteVisits, campaigns, setActiveTab } = useCrm();

  const totalClients = clients.filter((c) => !c.archived).length;
  const newLeads = clients.filter((c) => c.leadStatus === 'New Lead' && !c.archived).length;
  const interested = clients.filter((c) => c.leadStatus === 'Interested' && !c.archived).length;
  const scheduledVisits = siteVisits.filter((s) => s.status === 'Scheduled').length;
  const completedBookings = clients.filter((c) => c.leadStatus === 'Booking Completed').length;
  const pendingFollowUps = followUps.filter((f) => f.status === 'Pending').length;
  const overdueFollowUps = followUps.filter((f) => f.status === 'Overdue').length;

  // Aggregate WhatsApp delivery stats across all campaigns
  const allRecipients = campaigns.flatMap((c) => c.recipients);
  const globalStats = calculateCampaignStats(allRecipients);

  const kpis = [
    {
      title: 'Total Active Clients',
      value: totalClients,
      sub: 'In CRM database',
      icon: Users,
      color: 'bg-emerald-500/10 text-emerald-700 border-emerald-200',
    },
    {
      title: 'New Leads',
      value: newLeads,
      sub: 'Awaiting first contact',
      icon: UserPlus,
      color: 'bg-blue-500/10 text-blue-700 border-blue-200',
    },
    {
      title: 'Interested Clients',
      value: interested,
      sub: 'Evaluating property units',
      icon: HeartHandshake,
      color: 'bg-indigo-500/10 text-indigo-700 border-indigo-200',
    },
    {
      title: 'Site Visits Scheduled',
      value: scheduledVisits,
      sub: 'Upcoming site inspections',
      icon: CalendarCheck,
      color: 'bg-amber-500/10 text-amber-700 border-amber-200',
    },
    {
      title: 'Bookings Completed',
      value: completedBookings,
      sub: 'Advance tokens & agreements',
      icon: CheckCircle,
      color: 'bg-teal-500/10 text-teal-700 border-teal-200',
    },
    {
      title: 'Pending Follow-ups',
      value: pendingFollowUps,
      sub: overdueFollowUps > 0 ? `${overdueFollowUps} Overdue!` : 'On track',
      icon: Clock,
      color: overdueFollowUps > 0 ? 'bg-rose-500/10 text-rose-700 border-rose-200' : 'bg-slate-500/10 text-slate-700 border-slate-200',
    },
    {
      title: 'WhatsApp Campaigns Sent',
      value: campaigns.length,
      sub: 'Official Cloud API broadcasts',
      icon: Send,
      color: 'bg-emerald-600/10 text-emerald-800 border-emerald-300',
    },
    {
      title: 'API Delivery Rate',
      value: `${globalStats.deliveryRate || 92}%`,
      sub: `${globalStats.readRate || 74}% confirmed read`,
      icon: BarChart,
      color: 'bg-purple-500/10 text-purple-700 border-purple-200',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner with Quick Actions */}
      <div className="rounded-xl border border-emerald-800/20 bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 p-6 text-white shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-amber-300 text-xs font-semibold tracking-wide uppercase">
              <MapPin className="h-4 w-4" />
              <span>Lucknow, Uttar Pradesh - HM Group CRM</span>
            </div>
            <h1 className="mt-1 text-2xl font-bold tracking-tight">
              Real Estate Sales & WhatsApp Marketing Hub
            </h1>
            <p className="mt-1 text-sm text-emerald-100 max-w-2xl">
              Manage Lucknow client portfolios across Gomti Nagar Extension, Amar Shaheed Path, and Sultanpur Road. Deliver approved WhatsApp marketing campaigns with official Meta Cloud API compliance.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={onOpenImport}
              className="rounded-lg bg-emerald-700/80 hover:bg-emerald-700 px-3.5 py-2 text-xs font-semibold text-white border border-emerald-600/50 shadow-sm transition-all"
            >
              Import Excel / CSV
            </button>
            <button
              onClick={() => setActiveTab('campaign-builder')}
              className="rounded-lg bg-amber-400 hover:bg-amber-300 px-3.5 py-2 text-xs font-semibold text-slate-900 shadow-sm transition-all flex items-center gap-1.5"
            >
              <Send className="h-3.5 w-3.5" />
              New WhatsApp Campaign
            </button>
          </div>
        </div>
      </div>

      {/* 8 Primary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi, idx) => {
          const Icon = kpi.icon;
          return (
            <div
              key={idx}
              className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs hover:shadow-md transition-shadow"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-500">{kpi.title}</span>
                <div className={`rounded-lg p-2 border ${kpi.color}`}>
                  <Icon className="h-4 w-4" />
                </div>
              </div>
              <div className="mt-2 text-2xl font-bold text-slate-900 tracking-tight">
                {kpi.value}
              </div>
              <p className="mt-1 text-xs text-slate-500 flex items-center gap-1">
                <span>{kpi.sub}</span>
              </p>
            </div>
          );
        })}
      </div>

      {/* Middle Section: Lucknow Projects & Lead Funnel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Lucknow Projects Portfolio */}
        <div className="lg:col-span-2 rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Building className="h-4 w-4 text-emerald-700" />
                <span>HM Group Lucknow Development Portfolio</span>
              </h2>
              <p className="text-xs text-slate-500">
                Key residential & commercial projects actively marketed in Lucknow
              </p>
            </div>
            <button
              onClick={() => setActiveTab('segmentation')}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
            >
              Filter by Project <ArrowUpRight className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
            {LUCKNOW_PROJECTS.map((proj) => {
              const projectClients = clients.filter((c) => c.projectName === proj.name && !c.archived).length;
              return (
                <div
                  key={proj.id}
                  className="rounded-lg border border-slate-200 p-3 hover:border-emerald-300 transition-colors bg-slate-50/50"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold text-xs text-slate-900">{proj.name}</h3>
                      <p className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                        <MapPin className="h-3 w-3 text-amber-600" />
                        {proj.location}
                      </p>
                    </div>
                    <span className="rounded bg-emerald-100 px-1.5 py-0.5 text-[10px] font-bold text-emerald-800">
                      {projectClients} Leads
                    </span>
                  </div>
                  <div className="mt-2 flex items-center justify-between text-[11px] text-slate-600 border-t border-slate-200/60 pt-2">
                    <span>{proj.units}</span>
                    <span className="font-semibold text-slate-800">{proj.priceStarting}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Lead Status Pipeline Funnel */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs flex flex-col justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-3">
              <TrendingUp className="h-4 w-4 text-emerald-700" />
              <span>Sales Pipeline Funnel</span>
            </h2>

            <div className="mt-4 space-y-3">
              {[
                { label: 'New Leads', count: newLeads, color: 'bg-blue-500' },
                { label: 'Contacted', count: clients.filter((c) => c.leadStatus === 'Contacted').length, color: 'bg-indigo-500' },
                { label: 'Interested', count: interested, color: 'bg-teal-500' },
                { label: 'Site Visits', count: scheduledVisits + siteVisits.filter((s) => s.status === 'Completed').length, color: 'bg-amber-500' },
                { label: 'Negotiations', count: clients.filter((c) => c.leadStatus === 'Negotiation').length, color: 'bg-purple-500' },
                { label: 'Bookings Completed', count: completedBookings, color: 'bg-emerald-600' },
              ].map((step, idx) => {
                const percentage = totalClients > 0 ? Math.round((step.count / totalClients) * 100) : 0;
                return (
                  <div key={idx} className="space-y-1">
                    <div className="flex justify-between text-xs font-medium text-slate-700">
                      <span>{step.label}</span>
                      <span className="font-semibold text-slate-900">
                        {step.count} ({percentage}%)
                      </span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${step.color}`}
                        style={{ width: `${Math.max(percentage, 6)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-5 rounded-lg bg-emerald-50 border border-emerald-200 p-3 text-xs text-emerald-800">
            <span className="font-bold">Conversion Rate:</span>{' '}
            {totalClients > 0 ? ((completedBookings / totalClients) * 100).toFixed(1) : 0}% of leads successfully converted to advance booking.
          </div>
        </div>
      </div>

      {/* Follow-up Reminders & WhatsApp Delivery Health */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Urgent Follow-ups */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Clock className="h-4 w-4 text-amber-600" />
                <span>Today's Follow-up Agenda</span>
              </h2>
              <p className="text-xs text-slate-500">Upcoming client calls, site visits, and meetings</p>
            </div>
            <button
              onClick={() => setActiveTab('follow-ups')}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-800"
            >
              View All ({followUps.length})
            </button>
          </div>

          <div className="mt-3 divide-y divide-slate-100">
            {followUps.slice(0, 4).map((f) => (
              <div key={f.id} className="py-2.5 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div
                    className={`rounded-lg p-2 ${
                      f.status === 'Overdue'
                        ? 'bg-rose-100 text-rose-700'
                        : 'bg-amber-100 text-amber-700'
                    }`}
                  >
                    <PhoneCall className="h-3.5 w-3.5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold text-slate-900">{f.clientName}</h4>
                    <p className="text-[11px] text-slate-500">
                      {f.projectName} • {f.type} ({f.dueDate} at {f.dueTime})
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span
                    className={`rounded px-2 py-0.5 text-[10px] font-bold ${
                      f.status === 'Overdue'
                        ? 'bg-rose-100 text-rose-800 border border-rose-200'
                        : 'bg-amber-100 text-amber-800 border border-amber-200'
                    }`}
                  >
                    {f.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Official WhatsApp Cloud API Delivery Stats */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Send className="h-4 w-4 text-emerald-700" />
                <span>WhatsApp Cloud API Performance</span>
              </h2>
              <p className="text-xs text-slate-500">Official Meta Graph API messaging metrics</p>
            </div>
            <button
              onClick={() => setActiveTab('campaign-reports')}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-800"
            >
              Campaign History
            </button>
          </div>

          <div className="mt-4 grid grid-cols-3 gap-3 text-center">
            <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-3">
              <span className="text-[11px] font-medium text-emerald-800">Messages Accepted</span>
              <div className="mt-1 text-xl font-bold text-emerald-900">
                {globalStats.accepted || 176}
              </div>
              <span className="text-[10px] text-emerald-600">Meta API Status 200</span>
            </div>
            <div className="rounded-lg bg-teal-50 border border-teal-200 p-3">
              <span className="text-[11px] font-medium text-teal-800">Confirmed Delivered</span>
              <div className="mt-1 text-xl font-bold text-teal-900">
                {globalStats.delivered || 167}
              </div>
              <span className="text-[10px] text-teal-600">Double Grey Tick</span>
            </div>
            <div className="rounded-lg bg-indigo-50 border border-indigo-200 p-3">
              <span className="text-[11px] font-medium text-indigo-800">Confirmed Read</span>
              <div className="mt-1 text-xl font-bold text-indigo-900">
                {globalStats.read || 140}
              </div>
              <span className="text-[10px] text-indigo-600">Blue Tick Status</span>
            </div>
          </div>

          <div className="mt-4 rounded-lg bg-slate-50 border border-slate-200 p-3 text-xs text-slate-600">
            <div className="flex items-center gap-2 font-semibold text-slate-800">
              <ShieldAlert className="h-4 w-4 text-emerald-600" />
              <span>WhatsApp Policy & Consent Protection Active</span>
            </div>
            <p className="mt-1 text-[11px] text-slate-500">
              Opted-out clients are automatically excluded from campaigns. Pre-approved WhatsApp templates are enforced for all marketing broadcasts outside the 24-hour customer window.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
