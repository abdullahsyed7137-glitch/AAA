import React, { useState, useMemo } from 'react';
import {
  Users,
  Search,
  Filter,
  Download,
  Upload,
  Plus,
  Eye,
  Edit2,
  Archive,
  RotateCcw,
  MessageSquare,
  CheckSquare,
  Square,
  ExternalLink,
  Send,
  Building,
  CheckCircle2,
  XCircle,
  Clock,
  Sparkles,
} from 'lucide-react';
import { Client, LeadStatus, ConsentStatus } from '../types';
import { useCrm } from '../context/CrmContext';
import { formatIndianMobileDisplay, toWhatsAppApiFormat } from '../utils/clientValidation';
import { LUCKNOW_PROJECTS } from '../data/seedData';

interface ClientManagementViewProps {
  onOpenAddClient: () => void;
  onOpenImport: () => void;
  onViewClient: (client: Client) => void;
  onEditClient: (client: Client) => void;
}

export const ClientManagementView: React.FC<ClientManagementViewProps> = ({
  onOpenAddClient,
  onOpenImport,
  onViewClient,
  onEditClient,
}) => {
  const {
    clients,
    exportClients,
    archiveClient,
    restoreClient,
    selectedClientIds,
    toggleSelectClient,
    selectAllClients,
    clearSelection,
    setActiveTab,
    searchQuery,
    setSearchQuery,
  } = useCrm();

  const [projectFilter, setProjectFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [consentFilter, setConsentFilter] = useState<string>('ALL');
  const [showArchived, setShowArchived] = useState<boolean>(false);

  // Filtered clients list
  const filteredClients = useMemo(() => {
    return clients.filter((c) => {
      // Archive check
      if (!showArchived && c.archived) return false;
      if (showArchived && !c.archived) return false;

      // Project filter
      if (projectFilter !== 'ALL' && c.projectName !== projectFilter) return false;

      // Status filter
      if (statusFilter !== 'ALL' && c.leadStatus !== statusFilter) return false;

      // Consent filter
      if (consentFilter !== 'ALL' && c.whatsappConsent !== consentFilter) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = c.name.toLowerCase().includes(q);
        const matchesMobile = c.mobile.includes(q) || c.whatsappNumber.includes(q);
        const matchesProject = c.projectName.toLowerCase().includes(q);
        const matchesCity = c.city.toLowerCase().includes(q);
        const matchesBudget = c.budget.toLowerCase().includes(q);
        const matchesExecutive = c.assignedExecutive.toLowerCase().includes(q);
        return matchesName || matchesMobile || matchesProject || matchesCity || matchesBudget || matchesExecutive;
      }

      return true;
    });
  }, [clients, projectFilter, statusFilter, consentFilter, showArchived, searchQuery]);

  const eligibleForWhatsApp = filteredClients.filter((c) => c.whatsappConsent === 'Opted-in');

  const handleSelectAllFiltered = () => {
    if (selectedClientIds.length === filteredClients.length) {
      clearSelection();
    } else {
      selectAllClients(filteredClients.map((c) => c.id));
    }
  };

  const handleSelectOnlyEligible = () => {
    selectAllClients(eligibleForWhatsApp.map((c) => c.id));
  };

  return (
    <div className="space-y-4">
      {/* Top Header & Action Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Users className="h-5 w-5 text-emerald-800" />
            <span>Client & Lead Directory</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Total {clients.length} registered leads • {filteredClients.length} shown
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Export Button */}
          <button
            onClick={() => exportClients(filteredClients)}
            className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
            title="Download formatted Excel sheet (.xlsx)"
          >
            <Download className="h-3.5 w-3.5 text-emerald-700" />
            <span>Export to Excel</span>
          </button>

          {/* Import Button */}
          <button
            onClick={onOpenImport}
            className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
          >
            <Upload className="h-3.5 w-3.5 text-blue-700" />
            <span>Import Excel / CSV</span>
          </button>

          {/* Add Client */}
          <button
            onClick={onOpenAddClient}
            className="flex items-center gap-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 px-3.5 py-1.5 text-xs font-semibold text-white shadow-xs transition-colors"
          >
            <Plus className="h-4 w-4" />
            <span>Add New Client</span>
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
          {/* Search Input */}
          <div className="relative lg:col-span-2">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter by name, mobile, project, executive..."
              className="w-full rounded-lg border border-slate-300 pl-8 pr-3 py-1.5 text-xs text-slate-800 focus:border-emerald-600 focus:outline-none"
            />
          </div>

          {/* Project Filter */}
          <div>
            <select
              value={projectFilter}
              onChange={(e) => setProjectFilter(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs text-slate-700 focus:border-emerald-600 focus:outline-none"
            >
              <option value="ALL">All Lucknow Projects</option>
              {LUCKNOW_PROJECTS.map((p) => (
                <option key={p.id} value={p.name}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs text-slate-700 focus:border-emerald-600 focus:outline-none"
            >
              <option value="ALL">All Lead Statuses</option>
              <option value="New Lead">New Lead</option>
              <option value="Contacted">Contacted</option>
              <option value="Interested">Interested</option>
              <option value="Site Visit Scheduled">Site Visit Scheduled</option>
              <option value="Site Visit Completed">Site Visit Completed</option>
              <option value="Negotiation">Negotiation</option>
              <option value="Booking Completed">Booking Completed</option>
              <option value="Lost/Inactive">Lost/Inactive</option>
            </select>
          </div>

          {/* Consent Filter */}
          <div>
            <select
              value={consentFilter}
              onChange={(e) => setConsentFilter(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs text-slate-700 focus:border-emerald-600 focus:outline-none"
            >
              <option value="ALL">All WhatsApp Consents</option>
              <option value="Opted-in">Opted-in (Marketing Ready)</option>
              <option value="Opted-out">Opted-out (Unsubscribed)</option>
              <option value="Pending">Pending Verification</option>
            </select>
          </div>
        </div>

        {/* Quick Batch Selection Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 text-xs">
          <div className="flex items-center gap-3">
            <button
              onClick={handleSelectAllFiltered}
              className="font-medium text-slate-700 hover:text-slate-900 flex items-center gap-1.5"
            >
              {selectedClientIds.length > 0 && selectedClientIds.length === filteredClients.length ? (
                <CheckSquare className="h-4 w-4 text-emerald-700" />
              ) : (
                <Square className="h-4 w-4 text-slate-400" />
              )}
              <span>Select All Filtered ({filteredClients.length})</span>
            </button>

            <button
              onClick={handleSelectOnlyEligible}
              className="font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>Select All Eligible for WhatsApp ({eligibleForWhatsApp.length})</span>
            </button>

            {selectedClientIds.length > 0 && (
              <button
                onClick={clearSelection}
                className="text-slate-500 hover:text-slate-700 underline text-[11px]"
              >
                Clear Selection ({selectedClientIds.length})
              </button>
            )}
          </div>

          <div className="flex items-center gap-3">
            <label className="flex items-center gap-1.5 cursor-pointer text-slate-600 select-none">
              <input
                type="checkbox"
                checked={showArchived}
                onChange={(e) => setShowArchived(e.target.checked)}
                className="rounded border-slate-300 text-emerald-700 focus:ring-emerald-500"
              />
              <span>Show Archived ({clients.filter((c) => c.archived).length})</span>
            </label>

            {selectedClientIds.length > 0 && (
              <button
                onClick={() => setActiveTab('campaign-builder')}
                className="flex items-center gap-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 px-3 py-1 text-xs font-semibold text-white shadow-xs"
              >
                <Send className="h-3 w-3" />
                <span>Create WhatsApp Campaign ({selectedClientIds.length})</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main Client Table */}
      <div className="rounded-xl border border-slate-200 bg-white shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-3 w-8 text-center">
                  <span className="sr-only">Select</span>
                </th>
                <th className="py-3 px-3">Client Details</th>
                <th className="py-3 px-3">Contact (Calling & WhatsApp)</th>
                <th className="py-3 px-3">Project & Requirement</th>
                <th className="py-3 px-3">Budget</th>
                <th className="py-3 px-3">Lead Status</th>
                <th className="py-3 px-3">Sales Executive</th>
                <th className="py-3 px-3">Consent Status</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredClients.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-500">
                    <p className="font-semibold text-sm">No clients match your filter criteria.</p>
                    <p className="text-xs text-slate-400 mt-1">
                      Try clearing search terms or reset filters.
                    </p>
                  </td>
                </tr>
              ) : (
                filteredClients.map((client) => {
                  const isSelected = selectedClientIds.includes(client.id);
                  const isConsentOptedIn = client.whatsappConsent === 'Opted-in';

                  return (
                    <tr
                      key={client.id}
                      className={`hover:bg-slate-50/80 transition-colors ${
                        isSelected ? 'bg-emerald-50/40' : ''
                      } ${client.archived ? 'opacity-60 bg-slate-50' : ''}`}
                    >
                      {/* Checkbox */}
                      <td className="py-3 px-3 text-center">
                        <button
                          type="button"
                          onClick={() => toggleSelectClient(client.id)}
                          className="text-slate-400 hover:text-emerald-700"
                        >
                          {isSelected ? (
                            <CheckSquare className="h-4 w-4 text-emerald-700" />
                          ) : (
                            <Square className="h-4 w-4" />
                          )}
                        </button>
                      </td>

                      {/* Client Details */}
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900">{client.name}</div>
                        <div className="text-[11px] text-slate-500 flex items-center gap-1 font-mono">
                          <span>{client.id}</span> • <span>{client.city}</span>
                        </div>
                      </td>

                      {/* Contact */}
                      <td className="py-3 px-3">
                        <div className="text-slate-800 font-mono">
                          {formatIndianMobileDisplay(client.mobile)}
                        </div>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <a
                            href={`https://wa.me/${toWhatsAppApiFormat(client.whatsappNumber || client.mobile)}`}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-0.5 text-[11px] font-semibold text-emerald-700 hover:underline"
                            title="Direct WhatsApp chat"
                          >
                            <MessageSquare className="h-3 w-3" />
                            <span>WA: {formatIndianMobileDisplay(client.whatsappNumber)}</span>
                            <ExternalLink className="h-2.5 w-2.5" />
                          </a>
                        </div>
                      </td>

                      {/* Project & Property Interest */}
                      <td className="py-3 px-3">
                        <div className="font-semibold text-slate-900">{client.projectName}</div>
                        <div className="text-[11px] text-slate-500">{client.propertyInterest}</div>
                      </td>

                      {/* Budget */}
                      <td className="py-3 px-3">
                        <span className="font-bold text-emerald-900 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          {client.budget}
                        </span>
                      </td>

                      {/* Lead Status */}
                      <td className="py-3 px-3">
                        <span
                          className={`inline-block rounded-full px-2.5 py-0.5 text-[10px] font-bold ${
                            client.leadStatus === 'Booking Completed'
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                              : client.leadStatus === 'Site Visit Scheduled' || client.leadStatus === 'Site Visit Completed'
                              ? 'bg-amber-100 text-amber-800 border border-amber-300'
                              : client.leadStatus === 'Interested' || client.leadStatus === 'Negotiation'
                              ? 'bg-teal-100 text-teal-800 border border-teal-300'
                              : client.leadStatus === 'New Lead'
                              ? 'bg-blue-100 text-blue-800 border border-blue-300'
                              : 'bg-slate-100 text-slate-700 border border-slate-300'
                          }`}
                        >
                          {client.leadStatus}
                        </span>
                        {client.nextFollowUpDate && (
                          <div className="text-[10px] text-slate-500 mt-1 flex items-center gap-1">
                            <Clock className="h-2.5 w-2.5 text-amber-600" />
                            <span>Follow-up: {client.nextFollowUpDate}</span>
                          </div>
                        )}
                      </td>

                      {/* Sales Executive */}
                      <td className="py-3 px-3 text-slate-700 font-medium">
                        {client.assignedExecutive}
                      </td>

                      {/* Consent Status */}
                      <td className="py-3 px-3">
                        <span
                          className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[10px] font-bold ${
                            isConsentOptedIn
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                              : client.whatsappConsent === 'Opted-out'
                              ? 'bg-rose-100 text-rose-800 border border-rose-200'
                              : 'bg-amber-100 text-amber-800 border border-amber-200'
                          }`}
                        >
                          {isConsentOptedIn ? (
                            <CheckCircle2 className="h-3 w-3 text-emerald-600" />
                          ) : (
                            <XCircle className="h-3 w-3 text-rose-600" />
                          )}
                          <span>{client.whatsappConsent}</span>
                        </span>
                      </td>

                      {/* Action Buttons */}
                      <td className="py-3 px-3 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => onViewClient(client)}
                            className="rounded p-1 text-slate-600 hover:bg-slate-200 hover:text-slate-900 transition-colors"
                            title="View Full Profile & Notes"
                          >
                            <Eye className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => onEditClient(client)}
                            className="rounded p-1 text-slate-600 hover:bg-slate-200 hover:text-slate-900 transition-colors"
                            title="Edit Client"
                          >
                            <Edit2 className="h-4 w-4" />
                          </button>
                          {client.archived ? (
                            <button
                              onClick={() => restoreClient(client.id)}
                              className="rounded p-1 text-emerald-600 hover:bg-emerald-50 transition-colors"
                              title="Restore Client"
                            >
                              <RotateCcw className="h-4 w-4" />
                            </button>
                          ) : (
                            <button
                              onClick={() => archiveClient(client.id)}
                              className="rounded p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-colors"
                              title="Archive Client"
                            >
                              <Archive className="h-4 w-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
