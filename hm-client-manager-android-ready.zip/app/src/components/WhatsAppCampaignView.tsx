import React, { useState, useMemo, useRef } from 'react';
import {
  Send,
  Upload,
  FileImage,
  FileText,
  Eye,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Sparkles,
  Phone,
  MessageSquare,
  Building,
  Check,
  Calendar,
  X,
  ExternalLink,
  ShieldAlert,
  Info,
} from 'lucide-react';
import { useCrm } from '../context/CrmContext';
import { WhatsAppTemplate, WhatsAppCampaign } from '../types';
import { categorizeClientsForCampaign, renderTemplateText } from '../utils/whatsappHelper';

export const WhatsAppCampaignView: React.FC = () => {
  const {
    clients,
    selectedClientIds,
    templates,
    createCampaign,
    launchCampaign,
    apiConfig,
    setActiveTab,
  } = useCrm();

  const [campaignName, setCampaignName] = useState('');
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('tpl-01');
  const [customMode, setCustomMode] = useState<boolean>(false);
  const [customMessage, setCustomMessage] = useState('');
  const [mediaUrl, setMediaUrl] = useState<string>(
    'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&auto=format&fit=crop'
  );
  const [mediaType, setMediaType] = useState<'image' | 'document'>('image');
  const [mediaName, setMediaName] = useState('HM_Royal_Palms_Lucknow.jpg');
  const [sendTiming, setSendTiming] = useState<'instant' | 'scheduled'>('instant');
  const [scheduledDateTime, setScheduledDateTime] = useState('');

  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [isLaunching, setIsLaunching] = useState(false);
  const [launchResult, setLaunchResult] = useState<{ success: boolean; message: string } | null>(
    null
  );

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Selected clients resolution
  const targetClients = useMemo(() => {
    if (selectedClientIds.length > 0) {
      return clients.filter((c) => selectedClientIds.includes(c.id));
    }
    // Default to all active clients if none selected
    return clients.filter((c) => !c.archived);
  }, [clients, selectedClientIds]);

  // Breakdown
  const audienceBreakdown = useMemo(() => {
    return categorizeClientsForCampaign(targetClients);
  }, [targetClients]);

  // Current active template
  const activeTemplate = templates.find((t) => t.id === selectedTemplateId) || templates[0];

  // Preview message text
  const previewText = useMemo(() => {
    if (customMode) {
      return (
        customMessage ||
        'Namaste! HM Group of Companies presents luxury residential properties at Gomti Nagar Extension, Lucknow. Contact us today!'
      );
    }
    const sampleClient = audienceBreakdown.eligible[0] || clients[0];
    return renderTemplateText(activeTemplate?.body || '', [
      sampleClient?.name || 'Dr. Alok Srivastava',
      sampleClient?.projectName || 'HM Royal Palms',
      sampleClient?.assignedExecutive || 'Tariq Ansari',
    ]);
  }, [customMode, customMessage, activeTemplate, audienceBreakdown, clients]);

  const handleMediaUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const isPdf = file.type === 'application/pdf' || file.name.endsWith('.pdf');
      setMediaType(isPdf ? 'document' : 'image');
      setMediaName(file.name);

      const objectUrl = URL.createObjectURL(file);
      setMediaUrl(objectUrl);
    }
  };

  const handleTriggerCampaign = async () => {
    if (!campaignName.trim()) {
      alert('Please enter a campaign name');
      return;
    }

    if (audienceBreakdown.eligible.length === 0) {
      alert('No eligible opted-in recipients found for this campaign.');
      return;
    }

    setIsLaunching(true);
    try {
      const campaign = createCampaign({
        name: campaignName.trim(),
        status: sendTiming === 'scheduled' ? 'Scheduled' : 'Processing',
        messageType: customMode ? 'Custom' : 'Template',
        templateId: customMode ? undefined : activeTemplate.id,
        messageBody: previewText,
        mediaUrl: mediaUrl || undefined,
        mediaType: mediaUrl ? mediaType : undefined,
        mediaName: mediaUrl ? mediaName : undefined,
        targetSegmentDescription: `Audience of ${targetClients.length} clients (${audienceBreakdown.eligible.length} verified WhatsApp)`,
        totalAudience: targetClients.length,
        eligibleCount: audienceBreakdown.eligible.length,
        optedOutExcluded: audienceBreakdown.optedOut.length,
        invalidExcluded: audienceBreakdown.invalid.length,
        scheduledFor: sendTiming === 'scheduled' ? scheduledDateTime : undefined,
      });

      if (sendTiming === 'instant') {
        const res = await launchCampaign(campaign.id);
        setLaunchResult(res);
      } else {
        setLaunchResult({
          success: true,
          message: `Campaign scheduled for ${scheduledDateTime}. Messages queued for official WhatsApp Cloud API dispatch.`,
        });
      }
    } catch (err: any) {
      setLaunchResult({
        success: false,
        message: err.message || 'Failed to trigger campaign',
      });
    } finally {
      setIsLaunching(false);
      setShowConfirmModal(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Send className="h-5 w-5 text-emerald-800" />
            <span>Official WhatsApp Campaign Builder</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Meta Cloud API compliant broadcast studio with approved templates, promotional media, and consent safeguards.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div
            className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold border ${
              apiConfig.isConfigured
                ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
                : 'border-amber-300 bg-amber-50 text-amber-800'
            }`}
          >
            <MessageSquare className="h-3.5 w-3.5" />
            <span>
              {apiConfig.isConfigured
                ? 'Official WhatsApp Cloud API Active'
                : 'API Configuration Required'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Campaign Builder Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Form & Configuration (7 cols) */}
        <div className="lg:col-span-7 space-y-5">
          {/* 1. Campaign Details */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-2.5">
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-800 text-[11px] font-bold text-white">
                1
              </span>
              <span>Campaign Information</span>
            </h2>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Campaign Title *</label>
                <input
                  type="text"
                  required
                  value={campaignName}
                  onChange={(e) => setCampaignName(e.target.value)}
                  placeholder="e.g. HM Royal Palms Gomti Nagar - Pre-Launch VIP Offer"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs focus:border-emerald-600 focus:outline-none"
                />
              </div>

              {/* Mode switch */}
              <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                <div>
                  <span className="font-semibold text-slate-800">Use Meta Approved Template</span>
                  <p className="text-[11px] text-slate-500">
                    Recommended: Guaranteed WhatsApp Cloud API delivery outside 24h customer window
                  </p>
                </div>
                <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-slate-200">
                  <button
                    type="button"
                    onClick={() => setCustomMode(false)}
                    className={`rounded px-2.5 py-1 text-xs font-semibold ${
                      !customMode ? 'bg-emerald-800 text-white' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Template
                  </button>
                  <button
                    type="button"
                    onClick={() => setCustomMode(true)}
                    className={`rounded px-2.5 py-1 text-xs font-semibold ${
                      customMode ? 'bg-emerald-800 text-white' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Custom Text
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* 2. Message or Template Selection */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-2.5">
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-800 text-[11px] font-bold text-white">
                2
              </span>
              <span>{customMode ? 'Write Custom Message' : 'Select Approved WhatsApp Template'}</span>
            </h2>

            {!customMode ? (
              <div className="space-y-3 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Select Approved Template
                  </label>
                  <select
                    value={selectedTemplateId}
                    onChange={(e) => setSelectedTemplateId(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:border-emerald-600 focus:outline-none"
                  >
                    {templates.map((tpl) => (
                      <option key={tpl.id} value={tpl.id}>
                        {tpl.name} ({tpl.category} - {tpl.language}) [Status: {tpl.status}]
                      </option>
                    ))}
                  </select>
                </div>

                <div className="rounded-lg bg-emerald-50/70 border border-emerald-200 p-3 text-emerald-900">
                  <div className="font-semibold flex items-center gap-1.5 text-xs">
                    <CheckCircle2 className="h-4 w-4 text-emerald-700" />
                    <span>Template Status: {activeTemplate.status} by Meta</span>
                  </div>
                  <p className="mt-1 text-[11px] text-emerald-800">
                    Category: {activeTemplate.category} • Language: {activeTemplate.language} • Header:{' '}
                    {activeTemplate.headerType}
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-2 text-xs">
                <label className="block font-semibold text-slate-700">Custom WhatsApp Text</label>
                <textarea
                  rows={4}
                  value={customMessage}
                  onChange={(e) => setCustomMessage(e.target.value)}
                  placeholder="Enter message text... (Supports *bold*, _italic_, emoji)"
                  className="w-full rounded-lg border border-slate-300 p-2.5 text-xs focus:border-emerald-600 focus:outline-none"
                />
                <p className="text-[11px] text-amber-700">
                  Note: Business-initiated custom messages without templates can only be delivered if the customer messaged within the last 24 hours per WhatsApp policy.
                </p>
              </div>
            )}
          </div>

          {/* 3. Media Upload */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-2.5">
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-800 text-[11px] font-bold text-white">
                3
              </span>
              <span>Promotional Media (JPG, PNG, PDF)</span>
            </h2>

            <div className="space-y-3 text-xs">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-slate-50 hover:bg-slate-100 px-3 py-2 font-semibold text-slate-700 transition-colors"
                >
                  <Upload className="h-4 w-4 text-slate-500" />
                  <span>Choose Image / PDF Poster</span>
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/jpeg,image/png,application/pdf"
                  onChange={handleMediaUpload}
                  className="hidden"
                />
                {mediaName && (
                  <span className="text-slate-600 font-mono text-[11px] truncate max-w-xs">
                    {mediaName} ({mediaType.toUpperCase()})
                  </span>
                )}
              </div>

              {/* Sample preset Lucknow project posters */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1.5">
                  Or select official HM Group Lucknow property creative:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    {
                      label: 'HM Royal Palms',
                      url: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&auto=format&fit=crop',
                      file: 'hm_royal_palms_poster.jpg',
                    },
                    {
                      label: 'HM Green Meadows Villas',
                      url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&auto=format&fit=crop',
                      file: 'hm_villas_showcase.jpg',
                    },
                    {
                      label: 'HM Heights Hazratganj',
                      url: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&auto=format&fit=crop',
                      file: 'hm_heights_condos.jpg',
                    },
                  ].map((p, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setMediaUrl(p.url);
                        setMediaType('image');
                        setMediaName(p.file);
                      }}
                      className={`p-2 rounded-lg border text-left transition-all ${
                        mediaUrl === p.url
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-semibold ring-1 ring-emerald-600'
                          : 'border-slate-200 bg-white hover:border-slate-300 text-slate-700'
                      }`}
                    >
                      <span className="block text-[11px] truncate">{p.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* 4. Audience Safeguards & Scheduling */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-2.5">
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-800 text-[11px] font-bold text-white">
                4
              </span>
              <span>Audience Safeguards & Dispatch Schedule</span>
            </h2>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="rounded-lg bg-slate-50 border border-slate-200 p-2">
                  <span className="text-slate-500 block text-[11px]">Selected Audience</span>
                  <span className="text-base font-bold text-slate-900">
                    {targetClients.length}
                  </span>
                </div>
                <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-2">
                  <span className="text-emerald-800 block text-[11px] font-medium">
                    Verified Eligible
                  </span>
                  <span className="text-base font-bold text-emerald-900">
                    {audienceBreakdown.eligible.length}
                  </span>
                </div>
                <div className="rounded-lg bg-rose-50 border border-rose-200 p-2">
                  <span className="text-rose-800 block text-[11px] font-medium">
                    Opted-out Excluded
                  </span>
                  <span className="text-base font-bold text-rose-900">
                    {audienceBreakdown.optedOut.length}
                  </span>
                </div>
              </div>

              {/* Timing */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <label
                  onClick={() => setSendTiming('instant')}
                  className={`p-3 rounded-lg border cursor-pointer ${
                    sendTiming === 'instant'
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-900 ring-1 ring-emerald-600'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div className="font-semibold text-xs">Send Immediately</div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Trigger official WhatsApp Cloud API queue right now.
                  </p>
                </label>

                <label
                  onClick={() => setSendTiming('scheduled')}
                  className={`p-3 rounded-lg border cursor-pointer ${
                    sendTiming === 'scheduled'
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-900 ring-1 ring-emerald-600'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div className="font-semibold text-xs">Schedule for Later</div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Queue campaign for upcoming date and time.
                  </p>
                </label>
              </div>

              {sendTiming === 'scheduled' && (
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Scheduled Date & Time
                  </label>
                  <input
                    type="datetime-local"
                    value={scheduledDateTime}
                    onChange={(e) => setScheduledDateTime(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 p-2 text-xs focus:border-emerald-600 focus:outline-none"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Launch Button */}
          <div className="pt-2">
            <button
              type="button"
              onClick={() => setShowConfirmModal(true)}
              disabled={!campaignName.trim() || audienceBreakdown.eligible.length === 0}
              className="w-full rounded-xl bg-emerald-800 hover:bg-emerald-900 py-3 text-sm font-bold text-white shadow-md disabled:opacity-50 transition-all flex items-center justify-center gap-2"
            >
              <Send className="h-4 w-4" />
              <span>
                Review & Launch Campaign ({audienceBreakdown.eligible.length} Eligible Recipients)
              </span>
            </button>
          </div>
        </div>

        {/* Right Column: Live WhatsApp Interactive Chat Bubble Preview (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-xl border border-slate-200 bg-slate-900 p-4 text-white shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-300">
                Live WhatsApp Device Preview
              </span>
              <span className="text-[11px] text-slate-400">iOS / Android Viewport</span>
            </div>
          </div>

          {/* Realistic WhatsApp Chat Screen Mockup */}
          <div className="rounded-2xl border border-slate-300 bg-[#efeae2] shadow-md overflow-hidden relative min-h-[520px] flex flex-col justify-between">
            {/* WhatsApp Chat Header */}
            <div className="bg-[#075e54] text-white px-3.5 py-2.5 flex items-center justify-between shadow-xs">
              <div className="flex items-center gap-2.5">
                <div className="h-9 w-9 rounded-full bg-emerald-900 border border-emerald-400/40 flex items-center justify-center text-amber-300 font-bold text-xs">
                  HM
                </div>
                <div>
                  <div className="flex items-center gap-1">
                    <span className="font-semibold text-xs leading-none">HM Group of Companies</span>
                    <span className="h-3 w-3 rounded-full bg-emerald-400 text-slate-900 flex items-center justify-center text-[8px] font-black">
                      ✓
                    </span>
                  </div>
                  <span className="text-[10px] text-emerald-100">Official Business Account</span>
                </div>
              </div>
              <div className="flex items-center gap-2 text-emerald-100">
                <Phone className="h-3.5 w-3.5" />
              </div>
            </div>

            {/* Chat Body */}
            <div className="p-3.5 space-y-2 flex-1 flex flex-col justify-end">
              {/* WhatsApp Bubble */}
              <div className="max-w-[92%] rounded-xl rounded-tl-xs bg-white p-2 shadow-xs text-xs text-slate-900 border border-slate-200/60">
                {/* Media Image / Document Preview */}
                {mediaUrl && (
                  <div className="mb-2 rounded-lg overflow-hidden border border-slate-100 bg-slate-100">
                    {mediaType === 'image' ? (
                      <img
                        src={mediaUrl}
                        alt="Campaign media"
                        className="w-full h-44 object-cover"
                      />
                    ) : (
                      <div className="p-3 flex items-center gap-2 bg-slate-100 text-slate-800">
                        <FileText className="h-6 w-6 text-rose-600" />
                        <div>
                          <span className="font-semibold text-xs block">{mediaName}</span>
                          <span className="text-[10px] text-slate-500">PDF Document • 2.4 MB</span>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Body Text */}
                <div className="whitespace-pre-line text-xs text-slate-800 leading-relaxed font-sans px-1">
                  {previewText}
                </div>

                {/* Footer disclaimer */}
                {activeTemplate.footer && !customMode && (
                  <div className="mt-2 text-[10px] text-slate-400 border-t border-slate-100 pt-1 px-1">
                    {activeTemplate.footer}
                  </div>
                )}

                {/* Time & Sent status */}
                <div className="mt-1 flex items-center justify-end gap-1 text-[10px] text-slate-400 px-1">
                  <span>10:15 AM</span>
                  <span className="text-emerald-700 font-bold">✓✓</span>
                </div>

                {/* Interactive Action Buttons */}
                {activeTemplate.buttons && !customMode && (
                  <div className="mt-2 divide-y divide-slate-100 border-t border-slate-100">
                    {activeTemplate.buttons.map((btn, idx) => (
                      <div
                        key={idx}
                        className="py-1.5 text-center text-xs font-semibold text-[#00a884] hover:bg-slate-50 rounded-sm cursor-pointer flex items-center justify-center gap-1"
                      >
                        {btn.type === 'PHONE_NUMBER' && <Phone className="h-3 w-3" />}
                        {btn.type === 'URL' && <ExternalLink className="h-3 w-3" />}
                        <span>{btn.text}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Fake bottom WhatsApp input bar */}
            <div className="bg-[#f0f2f5] p-2 flex items-center gap-2 border-t border-slate-200">
              <div className="h-7 flex-1 rounded-full bg-white px-3 text-[11px] text-slate-400 flex items-center">
                Reply to HM Group...
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Confirmation Modal before launching */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-lg rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between border-b border-slate-100 bg-emerald-950 px-6 py-4 text-white">
              <div className="flex items-center gap-2">
                <ShieldAlert className="h-5 w-5 text-amber-300" />
                <h3 className="font-bold text-base">Confirm WhatsApp Broadcast</h3>
              </div>
              <button
                onClick={() => setShowConfirmModal(false)}
                className="rounded-lg p-1 text-slate-300 hover:bg-emerald-900 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="space-y-2 text-xs text-slate-700">
                <p>
                  You are about to launch campaign{' '}
                  <strong className="text-slate-900">"{campaignName}"</strong> through the official
                  WhatsApp Business Cloud API.
                </p>

                <div className="rounded-xl border border-slate-200 bg-slate-50 p-3.5 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Target Recipients:</span>
                    <strong className="text-emerald-800">
                      {audienceBreakdown.eligible.length} Opted-in Clients
                    </strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Excluded (Safeguards):</span>
                    <strong className="text-rose-800">
                      {audienceBreakdown.optedOut.length} Opted-out
                    </strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Message Format:</span>
                    <span className="font-medium text-slate-900">
                      {customMode ? 'Custom Text' : activeTemplate.name}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Dispatch Timing:</span>
                    <span className="font-medium text-slate-900">
                      {sendTiming === 'instant' ? 'Immediate API Dispatch' : scheduledDateTime}
                    </span>
                  </div>
                </div>

                {!apiConfig.isConfigured && (
                  <div className="rounded-lg bg-amber-50 border border-amber-300 p-3 text-amber-900 flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 shrink-0 text-amber-700 mt-0.5" />
                    <div>
                      <span className="font-bold">Official API Status Notice:</span>
                      <p className="mt-0.5 text-[11px]">
                        WhatsApp credentials (WHATSAPP_ACCESS_TOKEN and WHATSAPP_PHONE_NUMBER_ID) are currently missing from the backend environment. The application strictly respects requirement #10: simulated delivery is disabled. Attempting to send will return the official setup status until keys are configured.
                      </p>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowConfirmModal(false)}
                  className="rounded-lg border border-slate-300 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                >
                  Back to Editor
                </button>
                <button
                  type="button"
                  disabled={isLaunching}
                  onClick={handleTriggerCampaign}
                  className="rounded-lg bg-emerald-800 px-5 py-2 text-xs font-semibold text-white shadow-sm hover:bg-emerald-900 disabled:opacity-50 flex items-center gap-1.5"
                >
                  {isLaunching ? (
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                  <span>Launch WhatsApp Campaign</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Result Alert */}
      {launchResult && (
        <div
          className={`rounded-xl border p-4 text-xs ${
            launchResult.success
              ? 'border-emerald-300 bg-emerald-50 text-emerald-900'
              : 'border-rose-300 bg-rose-50 text-rose-900'
          }`}
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-2">
              {launchResult.success ? (
                <CheckCircle2 className="h-5 w-5 text-emerald-700 shrink-0" />
              ) : (
                <AlertTriangle className="h-5 w-5 text-rose-700 shrink-0" />
              )}
              <div>
                <h4 className="font-bold text-sm">
                  {launchResult.success ? 'Campaign Dispatched' : 'Campaign Notification'}
                </h4>
                <p className="mt-0.5">{launchResult.message}</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('campaign-reports')}
                className="font-semibold underline hover:no-underline"
              >
                View Campaign Reports
              </button>
              <button
                onClick={() => setLaunchResult(null)}
                className="rounded p-1 hover:bg-black/5"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
