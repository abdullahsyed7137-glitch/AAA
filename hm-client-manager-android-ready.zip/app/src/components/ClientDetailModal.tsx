import React, { useState } from 'react';
import {
  X,
  User,
  Phone,
  MessageSquare,
  MapPin,
  Building,
  CreditCard,
  Tag,
  Calendar,
  FileText,
  ShieldCheck,
  AlertCircle,
  Save,
  CheckCircle2,
} from 'lucide-react';
import { Client, LeadStatus, ConsentStatus } from '../types';
import { isValidIndianMobile, normalizeIndianPhone } from '../utils/clientValidation';
import { LUCKNOW_PROJECTS } from '../data/seedData';

interface ClientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (clientData: any) => void;
  initialData?: Client | null;
  mode: 'add' | 'edit';
}

export const ClientDetailModal: React.FC<ClientModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialData,
  mode,
}) => {
  if (!isOpen) return null;

  const [name, setName] = useState(initialData?.name || '');
  const [mobile, setMobile] = useState(initialData?.mobile || '');
  const [whatsappNumber, setWhatsappNumber] = useState(
    initialData?.whatsappNumber || initialData?.mobile || ''
  );
  const [city, setCity] = useState(initialData?.city || 'Lucknow');
  const [propertyInterest, setPropertyInterest] = useState(
    initialData?.propertyInterest || '3 BHK Premium Flat'
  );
  const [projectName, setProjectName] = useState(
    initialData?.projectName || 'HM Royal Palms'
  );
  const [budget, setBudget] = useState(initialData?.budget || '₹75L - ₹1.2 Cr');
  const [leadSource, setLeadSource] = useState(initialData?.leadSource || 'Direct Walk-in');
  const [leadStatus, setLeadStatus] = useState<LeadStatus>(
    initialData?.leadStatus || 'New Lead'
  );
  const [assignedExecutive, setAssignedExecutive] = useState(
    initialData?.assignedExecutive || 'Tariq Ansari'
  );
  const [lastContactDate, setLastContactDate] = useState(
    initialData?.lastContactDate || new Date().toISOString().split('T')[0]
  );
  const [nextFollowUpDate, setNextFollowUpDate] = useState(
    initialData?.nextFollowUpDate || ''
  );
  const [notes, setNotes] = useState(initialData?.notes || '');
  const [whatsappConsent, setWhatsappConsent] = useState<ConsentStatus>(
    initialData?.whatsappConsent || 'Opted-in'
  );

  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please provide client name');
      return;
    }

    const cleanMob = normalizeIndianPhone(mobile);
    if (!isValidIndianMobile(cleanMob)) {
      setError('Please enter a valid 10-digit Indian mobile number (e.g., 9839012345)');
      return;
    }

    const cleanWa = normalizeIndianPhone(whatsappNumber || mobile);
    if (!isValidIndianMobile(cleanWa)) {
      setError('Please enter a valid WhatsApp number');
      return;
    }

    setError(null);
    onSave({
      ...(initialData || {}),
      name: name.trim(),
      mobile: cleanMob,
      whatsappNumber: cleanWa,
      city: city.trim(),
      propertyInterest,
      projectName,
      budget,
      leadSource,
      leadStatus,
      assignedExecutive,
      lastContactDate,
      nextFollowUpDate,
      notes: notes.trim(),
      whatsappConsent,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-8">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-100 bg-emerald-900 px-6 py-4 text-white">
          <div className="flex items-center gap-2.5">
            <User className="h-5 w-5 text-amber-300" />
            <h3 className="font-bold text-base">
              {mode === 'add' ? 'Register New Real Estate Client' : `Edit Client: ${initialData?.name}`}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-slate-300 hover:bg-emerald-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="rounded-lg bg-rose-50 border border-rose-200 p-3 text-xs text-rose-700 flex items-center gap-2">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Full Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Client Full Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Dr. Alok Srivastava"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs focus:border-emerald-600 focus:outline-none focus:ring-1 focus:ring-emerald-600"
              />
            </div>

            {/* City */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Client City / Location *
              </label>
              <input
                type="text"
                required
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="e.g. Lucknow, Kanpur, Ayodhya..."
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs focus:border-emerald-600 focus:outline-none focus:ring-1 focus:ring-emerald-600"
              />
            </div>

            {/* Mobile Number */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Mobile Number (10 Digits) *
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-medium text-slate-400">
                  +91
                </span>
                <input
                  type="tel"
                  required
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  placeholder="9839012345"
                  className="w-full rounded-lg border border-slate-300 pl-10 pr-3 py-2 text-xs focus:border-emerald-600 focus:outline-none focus:ring-1 focus:ring-emerald-600"
                />
              </div>
            </div>

            {/* WhatsApp Number */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                WhatsApp Number *
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-medium text-slate-400">
                  +91
                </span>
                <input
                  type="tel"
                  required
                  value={whatsappNumber}
                  onChange={(e) => setWhatsappNumber(e.target.value)}
                  placeholder="Same as mobile or separate"
                  className="w-full rounded-lg border border-slate-300 pl-10 pr-3 py-2 text-xs focus:border-emerald-600 focus:outline-none focus:ring-1 focus:ring-emerald-600"
                />
              </div>
            </div>

            {/* Project Interest */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                HM Group Lucknow Project *
              </label>
              <select
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs focus:border-emerald-600 focus:outline-none focus:ring-1 focus:ring-emerald-600"
              >
                {LUCKNOW_PROJECTS.map((p) => (
                  <option key={p.id} value={p.name}>
                    {p.name} ({p.location.split(',')[0]})
                  </option>
                ))}
              </select>
            </div>

            {/* Property Interest */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Property Interest Type *
              </label>
              <select
                value={propertyInterest}
                onChange={(e) => setPropertyInterest(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs focus:border-emerald-600 focus:outline-none focus:ring-1 focus:ring-emerald-600"
              >
                <option value="Residential Plot">Residential Plot</option>
                <option value="2 BHK Luxury Apartment">2 BHK Luxury Apartment</option>
                <option value="3 BHK Premium Flat">3 BHK Premium Flat</option>
                <option value="4 BHK Penthouse">4 BHK Penthouse</option>
                <option value="Luxury Villa">Luxury Villa</option>
                <option value="Commercial Retail Shop">Commercial Retail Shop</option>
              </select>
            </div>

            {/* Budget */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Budget Bracket *
              </label>
              <select
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs focus:border-emerald-600 focus:outline-none focus:ring-1 focus:ring-emerald-600"
              >
                <option value="₹35 - ₹50 Lakhs">₹35 - ₹50 Lakhs</option>
                <option value="₹50 - ₹75 Lakhs">₹50 - ₹75 Lakhs</option>
                <option value="₹75L - ₹1.2 Cr">₹75L - ₹1.2 Cr</option>
                <option value="₹1.2 Cr - ₹2.5 Cr">₹1.2 Cr - ₹2.5 Cr</option>
                <option value="₹2.5 Cr+">₹2.5 Cr+</option>
              </select>
            </div>

            {/* Lead Status */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Lead Status *
              </label>
              <select
                value={leadStatus}
                onChange={(e) => setLeadStatus(e.target.value as LeadStatus)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs focus:border-emerald-600 focus:outline-none focus:ring-1 focus:ring-emerald-600"
              >
                <option value="New Lead">New Lead</option>
                <option value="Contacted">Contacted</option>
                <option value="Interested">Interested</option>
                <option value="Site Visit Scheduled">Site Visit Scheduled</option>
                <option value="Site Visit Completed">Site Visit Completed</option>
                <option value="Negotiation">Negotiation</option>
                <option value="Booking Completed">Booking Completed</option>
                <option value="Lost/Inactive">Lost/Inactive</option>
              </select>
            </div>

            {/* Lead Source */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Lead Acquisition Source *
              </label>
              <select
                value={leadSource}
                onChange={(e) => setLeadSource(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs focus:border-emerald-600 focus:outline-none focus:ring-1 focus:ring-emerald-600"
              >
                <option value="Direct Walk-in">Direct Walk-in</option>
                <option value="99acres">99acres</option>
                <option value="MagicBricks">MagicBricks</option>
                <option value="Meta Ads">Meta Ads (Facebook/Instagram)</option>
                <option value="WhatsApp Inbound">WhatsApp Inbound</option>
                <option value="Referral">Referral / Word of Mouth</option>
                <option value="Hoardings / Print">Hoardings / Newspaper</option>
                <option value="Excel Import">Excel Import</option>
              </select>
            </div>

            {/* Assigned Executive */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Assigned Sales Executive *
              </label>
              <select
                value={assignedExecutive}
                onChange={(e) => setAssignedExecutive(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs focus:border-emerald-600 focus:outline-none focus:ring-1 focus:ring-emerald-600"
              >
                <option value="Tariq Ansari">Tariq Ansari (Senior RM)</option>
                <option value="Neha Sharma">Neha Sharma (Luxury Lead)</option>
                <option value="Amit Verma">Amit Verma (Commercial/Plots)</option>
                <option value="Pooja Singh">Pooja Singh (Client Associate)</option>
              </select>
            </div>

            {/* Next Follow-up Date */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Next Follow-up Date
              </label>
              <input
                type="date"
                value={nextFollowUpDate}
                onChange={(e) => setNextFollowUpDate(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs focus:border-emerald-600 focus:outline-none focus:ring-1 focus:ring-emerald-600"
              />
            </div>

            {/* WhatsApp Marketing Consent */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                WhatsApp Marketing Consent Status *
              </label>
              <select
                value={whatsappConsent}
                onChange={(e) => setWhatsappConsent(e.target.value as ConsentStatus)}
                className={`w-full rounded-lg border px-3 py-2 text-xs font-medium focus:outline-none ${
                  whatsappConsent === 'Opted-in'
                    ? 'border-emerald-500 bg-emerald-50 text-emerald-800'
                    : whatsappConsent === 'Opted-out'
                    ? 'border-rose-500 bg-rose-50 text-rose-800'
                    : 'border-amber-500 bg-amber-50 text-amber-800'
                }`}
              >
                <option value="Opted-in">Opted-in (Eligible for Broadcasts)</option>
                <option value="Opted-out">Opted-out (Do NOT Send Marketing)</option>
                <option value="Pending">Pending Consent Verification</option>
              </select>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Client Call Notes / Preferences
            </label>
            <textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Visited Gomti Nagar office. Wants park facing unit with payment plan details..."
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs focus:border-emerald-600 focus:outline-none focus:ring-1 focus:ring-emerald-600"
            />
          </div>

          {/* Modal Footer */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-300 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-lg bg-emerald-800 px-5 py-2 text-xs font-semibold text-white shadow-sm hover:bg-emerald-900 transition-colors flex items-center gap-1.5"
            >
              <Save className="h-4 w-4" />
              <span>{mode === 'add' ? 'Save Client Record' : 'Update Client'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
