import React, { useState, useMemo } from 'react';
import {
  Filter,
  Users,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Send,
  Building,
  RotateCcw,
  Sparkles,
  CheckSquare,
  Square,
} from 'lucide-react';
import { useCrm } from '../context/CrmContext';
import { LUCKNOW_PROJECTS } from '../data/seedData';
import { categorizeClientsForCampaign } from '../utils/whatsappHelper';
import { formatIndianMobileDisplay } from '../utils/clientValidation';

export const ClientSegmentationView: React.FC = () => {
  const {
    clients,
    selectedClientIds,
    toggleSelectClient,
    selectAllClients,
    clearSelection,
    setActiveTab,
  } = useCrm();

  const [cityFilter, setCityFilter] = useState<string>('ALL');
  const [projectFilter, setProjectFilter] = useState<string>('ALL');
  const [propertyTypeFilter, setPropertyTypeFilter] = useState<string>('ALL');
  const [budgetFilter, setBudgetFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [executiveFilter, setExecutiveFilter] = useState<string>('ALL');
  const [consentOnly, setConsentOnly] = useState<boolean>(true);
  const [contactRecency, setContactRecency] = useState<string>('ALL');

  // Filter clients
  const segmentedClients = useMemo(() => {
    return clients.filter((c) => {
      if (c.archived) return false;
      if (cityFilter !== 'ALL' && c.city !== cityFilter) return false;
      if (projectFilter !== 'ALL' && c.projectName !== projectFilter) return false;
      if (propertyTypeFilter !== 'ALL' && c.propertyInterest !== propertyTypeFilter) return false;
      if (budgetFilter !== 'ALL' && c.budget !== budgetFilter) return false;
      if (statusFilter !== 'ALL' && c.leadStatus !== statusFilter) return false;
      if (executiveFilter !== 'ALL' && c.assignedExecutive !== executiveFilter) return false;
      if (consentOnly && c.whatsappConsent !== 'Opted-in') return false;

      // Contact recency
      if (contactRecency !== 'ALL' && c.lastContactDate) {
        const diffDays = Math.floor(
          (Date.now() - new Date(c.lastContactDate).getTime()) / (1000 * 3600 * 24)
        );
        if (contactRecency === '7' && diffDays > 7) return false;
        if (contactRecency === '15' && diffDays > 15) return false;
        if (contactRecency === '30' && diffDays > 30) return false;
        if (contactRecency === '60plus' && diffDays <= 60) return false;
      }

      return true;
    });
  }, [
    clients,
    cityFilter,
    projectFilter,
    propertyTypeFilter,
    budgetFilter,
    statusFilter,
    executiveFilter,
    consentOnly,
    contactRecency,
  ]);

  // WhatsApp Eligibility Categorization
  const audienceCategorization = useMemo(() => {
    return categorizeClientsForCampaign(segmentedClients);
  }, [segmentedClients]);

  const resetFilters = () => {
    setCityFilter('ALL');
    setProjectFilter('ALL');
    setPropertyTypeFilter('ALL');
    setBudgetFilter('ALL');
    setStatusFilter('ALL');
    setExecutiveFilter('ALL');
    setConsentOnly(true);
    setContactRecency('ALL');
  };

  const handleSelectAllSegment = () => {
    selectAllClients(segmentedClients.map((c) => c.id));
  };

  const handleSelectOnlyEligibleSegment = () => {
    selectAllClients(audienceCategorization.eligible.map((c) => c.id));
  };

  const handleLaunchCampaignWithSegment = () => {
    if (selectedClientIds.length === 0) {
      // If none explicitly selected, select all eligible
      selectAllClients(audienceCategorization.eligible.map((c) => c.id));
    }
    setActiveTab('campaign-builder');
  };

  return (
    <div className="space-y-6">
      {/* Title Banner */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Filter className="h-5 w-5 text-emerald-800" />
            <span>Client Segmentation & WhatsApp Audience Builder</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Target high-intent Lucknow buyers by project, budget, property requirement, and verified WhatsApp marketing consent.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={resetFilters}
            className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Reset Filters</span>
          </button>

          <button
            onClick={handleLaunchCampaignWithSegment}
            disabled={segmentedClients.length === 0}
            className="flex items-center gap-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 px-4 py-1.5 text-xs font-semibold text-white shadow-xs disabled:opacity-50"
          >
            <Send className="h-3.5 w-3.5" />
            <span>Target in WhatsApp Campaign</span>
          </button>
        </div>
      </div>

      {/* Multi-Parameter Filter Grid */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
        <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider text-slate-500">
          Target Audience Filters
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          {/* City */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Target City</label>
            <select
              value={cityFilter}
              onChange={(e) => setCityFilter(e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-2 focus:border-emerald-600 focus:outline-none"
            >
              <option value="ALL">All Cities (Lucknow, Kanpur, etc.)</option>
              <option value="Lucknow">Lucknow (Local)</option>
              <option value="Kanpur">Kanpur</option>
              <option value="Ayodhya">Ayodhya</option>
              <option value="Varanasi">Varanasi</option>
              <option value="Gorakhpur">Gorakhpur</option>
              <option value="Delhi NCR">Delhi NCR</option>
            </select>
          </div>

          {/* Project */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">HM Project</label>
            <select
              value={projectFilter}
              onChange={(e) => setProjectFilter(e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-2 focus:border-emerald-600 focus:outline-none"
            >
              <option value="ALL">All HM Group Projects</option>
              {LUCKNOW_PROJECTS.map((p) => (
                <option key={p.id} value={p.name}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>

          {/* Property Type */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Property Type</label>
            <select
              value={propertyTypeFilter}
              onChange={(e) => setPropertyTypeFilter(e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-2 focus:border-emerald-600 focus:outline-none"
            >
              <option value="ALL">All Property Types</option>
              <option value="Residential Plot">Residential Plot</option>
              <option value="2 BHK Luxury Apartment">2 BHK Luxury Apartment</option>
              <option value="3 BHK Premium Flat">3 BHK Premium Flat</option>
              <option value="4 BHK Penthouse">4 BHK Penthouse</option>
              <option value="Luxury Villa">Luxury Villa</option>
              <option value="Commercial Retail Shop">Commercial Retail Shop</option>
            </select>
          </div>

          {/* Budget */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Budget Bracket</label>
            <select
              value={budgetFilter}
              onChange={(e) => setBudgetFilter(e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-2 focus:border-emerald-600 focus:outline-none"
            >
              <option value="ALL">Any Budget</option>
              <option value="₹35 - ₹50 Lakhs">₹35 - ₹50 Lakhs</option>
              <option value="₹50 - ₹75 Lakhs">₹50 - ₹75 Lakhs</option>
              <option value="₹75L - ₹1.2 Cr">₹75L - ₹1.2 Cr</option>
              <option value="₹1.2 Cr - ₹2.5 Cr">₹1.2 Cr - ₹2.5 Cr</option>
              <option value="₹2.5 Cr+">₹2.5 Cr+</option>
            </select>
          </div>

          {/* Lead Status */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Lead Pipeline Status</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-2 focus:border-emerald-600 focus:outline-none"
            >
              <option value="ALL">All Lead Statuses</option>
              <option value="New Lead">New Lead</option>
              <option value="Contacted">Contacted</option>
              <option value="Interested">Interested</option>
              <option value="Site Visit Scheduled">Site Visit Scheduled</option>
              <option value="Site Visit Completed">Site Visit Completed</option>
              <option value="Negotiation">Negotiation</option>
              <option value="Booking Completed">Booking Completed</option>
            </select>
          </div>

          {/* Sales Executive */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Sales Executive</label>
            <select
              value={executiveFilter}
              onChange={(e) => setExecutiveFilter(e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-2 focus:border-emerald-600 focus:outline-none"
            >
              <option value="ALL">All Executives</option>
              <option value="Tariq Ansari">Tariq Ansari</option>
              <option value="Neha Sharma">Neha Sharma</option>
              <option value="Amit Verma">Amit Verma</option>
              <option value="Pooja Singh">Pooja Singh</option>
            </select>
          </div>

          {/* Last Contact Recency */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Last Contacted</label>
            <select
              value={contactRecency}
              onChange={(e) => setContactRecency(e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-2 focus:border-emerald-600 focus:outline-none"
            >
              <option value="ALL">Anytime</option>
              <option value="7">Within last 7 days</option>
              <option value="15">Within last 15 days</option>
              <option value="30">Within last 30 days</option>
              <option value="60plus">Inactive (Over 60 days)</option>
            </select>
          </div>

          {/* Consent Checkbox */}
          <div className="flex flex-col justify-end">
            <label className="flex items-center gap-2 p-2 rounded-lg bg-emerald-50 border border-emerald-200 cursor-pointer text-emerald-900 select-none">
              <input
                type="checkbox"
                checked={consentOnly}
                onChange={(e) => setConsentOnly(e.target.checked)}
                className="rounded border-emerald-400 text-emerald-700 focus:ring-emerald-500"
              />
              <span className="font-semibold text-xs">Opted-in Clients Only</span>
            </label>
          </div>
        </div>
      </div>

      {/* Audience Eligibility Breakdown Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-xs font-medium text-slate-500">Segment Match Count</span>
          <div className="mt-1 text-2xl font-bold text-slate-900">
            {segmentedClients.length} clients
          </div>
          <span className="text-[11px] text-slate-400">Matching criteria filters</span>
        </div>

        <div className="rounded-xl border border-emerald-200 bg-emerald-50/50 p-4 shadow-xs">
          <span className="text-xs font-semibold text-emerald-800">WhatsApp Eligible Recipients</span>
          <div className="mt-1 text-2xl font-bold text-emerald-900">
            {audienceCategorization.eligible.length} recipients
          </div>
          <span className="text-[11px] text-emerald-700 flex items-center gap-1 mt-0.5">
            <CheckCircle2 className="h-3 w-3 text-emerald-600" />
            Verified Indian mobile + Opted-in consent
          </span>
        </div>

        <div className="rounded-xl border border-amber-200 bg-amber-50/50 p-4 shadow-xs">
          <span className="text-xs font-semibold text-amber-800">Excluded Safeguards</span>
          <div className="mt-1 text-2xl font-bold text-amber-900">
            {audienceCategorization.optedOut.length + audienceCategorization.invalid.length} excluded
          </div>
          <span className="text-[11px] text-amber-700 flex items-center gap-1 mt-0.5">
            <AlertTriangle className="h-3 w-3 text-amber-600" />
            {audienceCategorization.optedOut.length} opted out, {audienceCategorization.invalid.length} invalid format
          </span>
        </div>
      </div>

      {/* Matching Clients List */}
      <div className="rounded-xl border border-slate-200 bg-white shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-slate-50/50">
          <div className="flex items-center gap-3">
            <button
              onClick={handleSelectAllSegment}
              className="text-xs font-semibold text-slate-700 hover:text-slate-900 flex items-center gap-1.5"
            >
              <CheckSquare className="h-4 w-4 text-emerald-700" />
              <span>Select All in Segment ({segmentedClients.length})</span>
            </button>

            <button
              onClick={handleSelectOnlyEligibleSegment}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>Select Only WhatsApp Eligible ({audienceCategorization.eligible.length})</span>
            </button>
          </div>

          <span className="text-xs text-slate-500 font-medium">
            Currently selected for campaign: <strong>{selectedClientIds.length}</strong>
          </span>
        </div>

        <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto">
          {segmentedClients.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-xs">
              No clients match this specific segmentation combination. Try broadening your criteria.
            </div>
          ) : (
            segmentedClients.map((client) => {
              const isSelected = selectedClientIds.includes(client.id);
              const isEligible = client.whatsappConsent === 'Opted-in';

              return (
                <div
                  key={client.id}
                  className={`p-3 flex items-center justify-between hover:bg-slate-50 transition-colors ${
                    isSelected ? 'bg-emerald-50/30' : ''
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => toggleSelectClient(client.id)}
                      className="text-slate-400 hover:text-emerald-700"
                    >
                      {isSelected ? (
                        <CheckSquare className="h-4 w-4 text-emerald-700" />
                      ) : (
                        <Square className="h-4 w-4" />
                      )}
                    </button>
                    <div>
                      <div className="font-bold text-xs text-slate-900">{client.name}</div>
                      <div className="text-[11px] text-slate-500">
                        {client.city} • {client.projectName} • {client.propertyInterest} •{' '}
                        <strong className="text-slate-700">{client.budget}</strong>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs text-slate-600">
                      {formatIndianMobileDisplay(client.whatsappNumber || client.mobile)}
                    </span>
                    <span
                      className={`rounded px-2 py-0.5 text-[10px] font-bold ${
                        isEligible
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {client.whatsappConsent}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
