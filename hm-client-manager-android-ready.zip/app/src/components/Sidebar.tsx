import React from 'react';
import {
  LayoutDashboard,
  Users,
  Filter,
  Send,
  BarChart3,
  CalendarClock,
  FileText,
  ShieldCheck,
  Settings,
  Building,
  CheckCircle2,
} from 'lucide-react';
import { useCrm } from '../context/CrmContext';

interface SidebarProps {
  onOpenSettings: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onOpenSettings }) => {
  const { activeTab, setActiveTab, clients, followUps, campaigns } = useCrm();

  const overdueFollowUps = followUps.filter((f) => f.status === 'Overdue').length;
  const activeClientsCount = clients.filter((c) => !c.archived).length;

  const navItems = [
    { id: 'dashboard', label: 'Admin Dashboard', icon: LayoutDashboard },
    {
      id: 'clients',
      label: 'Client Management',
      icon: Users,
      badge: activeClientsCount,
    },
    { id: 'segmentation', label: 'Client Segmentation', icon: Filter },
    { id: 'campaign-builder', label: 'WhatsApp Campaign', icon: Send },
    {
      id: 'campaign-reports',
      label: 'Campaign Reports',
      icon: BarChart3,
      badge: campaigns.length,
    },
    {
      id: 'follow-ups',
      label: 'Follow-ups & Visits',
      icon: CalendarClock,
      alertBadge: overdueFollowUps > 0 ? `${overdueFollowUps} Overdue` : undefined,
    },
    { id: 'templates', label: 'Message Templates', icon: FileText },
    { id: 'audit', label: 'Security & Audit Logs', icon: ShieldCheck },
  ];

  return (
    <aside className="w-64 shrink-0 border-r border-slate-200 bg-slate-900 text-slate-300 flex flex-col justify-between hidden md:flex min-h-[calc(100vh-4rem)]">
      <div className="p-4 space-y-6">
        {/* HM Group Lucknow Badge */}
        <div className="rounded-lg bg-slate-800/80 p-3 border border-slate-700/60">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-400">
            <Building className="h-4 w-4" />
            <span>Lucknow Headquarters</span>
          </div>
          <p className="mt-1 text-[11px] text-slate-400">
            Gomti Nagar Ext. | Shaheed Path | Hazratganj
          </p>
        </div>

        {/* Navigation list */}
        <nav className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between rounded-lg px-3 py-2.5 text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-emerald-700 text-white shadow-sm'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`h-4 w-4 ${isActive ? 'text-amber-300' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.alertBadge && (
                  <span className="rounded bg-rose-500/20 px-1.5 py-0.5 text-[10px] font-semibold text-rose-300 border border-rose-500/30">
                    {item.alertBadge}
                  </span>
                )}
                {item.badge !== undefined && !item.alertBadge && (
                  <span className="rounded bg-slate-800 px-1.5 py-0.5 text-[10px] font-semibold text-slate-300 border border-slate-700">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Setup & Status */}
      <div className="p-4 border-t border-slate-800 space-y-2">
        <button
          onClick={onOpenSettings}
          className="w-full flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800 transition-colors"
        >
          <Settings className="h-4 w-4 text-emerald-400" />
          <span>WhatsApp API Setup Guide</span>
        </button>

        <div className="flex items-center gap-2 rounded-lg bg-emerald-950/40 border border-emerald-800/40 p-2.5 text-[11px] text-emerald-300">
          <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
          <span>Official Meta WhatsApp Cloud API v19.0 Integration</span>
        </div>
      </div>
    </aside>
  );
};
