import React, { useState } from 'react';
import {
  X,
  User,
  Phone,
  MessageSquare,
  MapPin,
  Building,
  CreditCard,
  Tag,
  Calendar,
  Clock,
  Shield,
  FileText,
  Edit2,
  Archive,
  RotateCcw,
  Plus,
  Send,
  ExternalLink,
} from 'lucide-react';
import { Client, FollowUp, SiteVisit } from '../types';
import { formatIndianMobileDisplay, toWhatsAppApiFormat } from '../utils/clientValidation';
import { useCrm } from '../context/CrmContext';

interface ClientDetailDrawerProps {
  client: Client | null;
  onClose: () => void;
  onEdit: (client: Client) => void;
}

export const ClientDetailDrawer: React.FC<ClientDetailDrawerProps> = ({
  client,
  onClose,
  onEdit,
}) => {
  const {
    followUps,
    siteVisits,
    archiveClient,
    restoreClient,
    updateClient,
    addFollowUp,
    addSiteVisit,
    setActiveTab,
    toggleSelectClient,
    selectedClientIds,
  } = useCrm();

  const [newNote, setNewNote] = useState('');
  const [showAddFollowUp, setShowAddFollowUp] = useState(false);
  const [newFollowUpDate, setNewFollowUpDate] = useState('');
  const [newFollowUpTime, setNewFollowUpTime] = useState('11:00');
  const [newFollowUpType, setNewFollowUpType] = useState<any>('Call');
  const [newFollowUpNotes, setNewFollowUpNotes] = useState('');

  if (!client) return null;

  const clientFollowUps = followUps.filter((f) => f.clientId === client.id);
  const clientVisits = siteVisits.filter((s) => s.clientId === client.id);
  const isSelected = selectedClientIds.includes(client.id);

  const handleAppendNote = () => {
    if (!newNote.trim()) return;
    const timestamp = new Date().toLocaleDateString('en-IN', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
    const updatedNotes = `${client.notes}\n[${timestamp}]: ${newNote.trim()}`;
    updateClient({
      ...client,
      notes: updatedNotes,
      lastContactDate: new Date().toISOString().split('T')[0],
    });
    setNewNote('');
  };

  const handleCreateFollowUp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFollowUpDate) return;
    addFollowUp({
      clientId: client.id,
      clientName: client.name,
      clientMobile: client.mobile,
      assignedExecutive: client.assignedExecutive,
      dueDate: newFollowUpDate,
      dueTime: newFollowUpTime,
      type: newFollowUpType,
      status: 'Pending',
      projectName: client.projectName,
      notes: newFollowUpNotes || 'Scheduled from client drawer',
    });
    updateClient({
      ...client,
      nextFollowUpDate: newFollowUpDate,
    });
    setShowAddFollowUp(false);
    setNewFollowUpNotes('');
  };

  const handleConsentToggle = (newStatus: 'Opted-in' | 'Opted-out' | 'Pending') => {
    updateClient({
      ...client,
      whatsappConsent: newStatus,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/50 backdrop-blur-xs">
      <div className="h-full w-full max-w-xl bg-white shadow-2xl flex flex-col justify-between overflow-hidden border-l border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-emerald-950 px-6 py-4 text-white">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs text-amber-300 font-semibold">{client.id}</span>
              {client.archived && (
                <span className="rounded bg-rose-500/30 px-1.5 py-0.5 text-[10px] font-bold text-rose-300">
                  Archived
                </span>
              )}
            </div>
            <h2 className="text-lg font-bold tracking-tight text-white mt-0.5">{client.name}</h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onEdit(client)}
              className="rounded-lg p-2 text-slate-300 hover:bg-emerald-900 hover:text-white transition-colors"
              title="Edit Client"
            >
              <Edit2 className="h-4 w-4" />
            </button>
            <button
              onClick={onClose}
              className="rounded-lg p-2 text-slate-300 hover:bg-emerald-900 hover:text-white transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Quick Contact & WhatsApp Bar */}
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-800">
                  <Phone className="h-3.5 w-3.5 text-slate-500" />
                  <span>Mobile: {formatIndianMobileDisplay(client.mobile)}</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800">
                  <MessageSquare className="h-3.5 w-3.5 text-emerald-600" />
                  <span>WhatsApp: {formatIndianMobileDisplay(client.whatsappNumber)}</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <a
                  href={`https://wa.me/${toWhatsAppApiFormat(client.whatsappNumber || client.mobile)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1 rounded-lg bg-emerald-700 hover:bg-emerald-800 px-3 py-1.5 text-xs font-semibold text-white shadow-xs"
                >
                  <MessageSquare className="h-3.5 w-3.5" />
                  <span>Chat on WhatsApp</span>
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>

            {/* WhatsApp Marketing Consent Indicator & Controls */}
            <div className="mt-3 pt-3 border-t border-slate-200 flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-700">WhatsApp Consent:</span>
              <div className="flex items-center gap-1 text-xs">
                {(['Opted-in', 'Opted-out', 'Pending'] as const).map((st) => (
                  <button
                    key={st}
                    onClick={() => handleConsentToggle(st)}
                    className={`rounded-md px-2 py-1 text-[11px] font-semibold transition-colors ${
                      client.whatsappConsent === st
                        ? st === 'Opted-in'
                          ? 'bg-emerald-700 text-white'
                          : st === 'Opted-out'
                          ? 'bg-rose-700 text-white'
                          : 'bg-amber-600 text-white'
                        : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Core Real Estate Requirements */}
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div className="rounded-lg border border-slate-200 p-3 bg-white">
              <span className="text-slate-500 font-medium block">Project Name</span>
              <span className="font-bold text-slate-900 mt-0.5 block">{client.projectName}</span>
            </div>

            <div className="rounded-lg border border-slate-200 p-3 bg-white">
              <span className="text-slate-500 font-medium block">Property Interest</span>
              <span className="font-bold text-slate-900 mt-0.5 block">
                {client.propertyInterest}
              </span>
            </div>

            <div className="rounded-lg border border-slate-200 p-3 bg-white">
              <span className="text-slate-500 font-medium block">Budget</span>
              <span className="font-bold text-emerald-800 mt-0.5 block">{client.budget}</span>
            </div>

            <div className="rounded-lg border border-slate-200 p-3 bg-white">
              <span className="text-slate-500 font-medium block">City / Origin</span>
              <span className="font-bold text-slate-900 mt-0.5 block">{client.city}</span>
            </div>

            <div className="rounded-lg border border-slate-200 p-3 bg-white">
              <span className="text-slate-500 font-medium block">Lead Status</span>
              <span className="font-bold text-slate-900 mt-0.5 block">{client.leadStatus}</span>
            </div>

            <div className="rounded-lg border border-slate-200 p-3 bg-white">
              <span className="text-slate-500 font-medium block">Sales Executive</span>
              <span className="font-bold text-slate-900 mt-0.5 block">
                {client.assignedExecutive}
              </span>
            </div>
          </div>

          {/* Follow-up Reminders */}
          <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-amber-600" />
                <h4 className="font-bold text-xs text-slate-900">Scheduled Follow-ups</h4>
              </div>
              <button
                onClick={() => setShowAddFollowUp(!showAddFollowUp)}
                className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Schedule New</span>
              </button>
            </div>

            {/* Quick Follow-up Form */}
            {showAddFollowUp && (
              <form
                onSubmit={handleCreateFollowUp}
                className="rounded-lg bg-slate-50 border border-slate-200 p-3 space-y-2.5 text-xs"
              >
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700">Date</label>
                    <input
                      type="date"
                      required
                      value={newFollowUpDate}
                      onChange={(e) => setNewFollowUpDate(e.target.value)}
                      className="w-full rounded border border-slate-300 p-1.5"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700">Type</label>
                    <select
                      value={newFollowUpType}
                      onChange={(e) => setNewFollowUpType(e.target.value)}
                      className="w-full rounded border border-slate-300 p-1.5"
                    >
                      <option value="Call">Call</option>
                      <option value="Site Visit">Site Visit</option>
                      <option value="Meeting">Meeting</option>
                      <option value="WhatsApp Reminder">WhatsApp Reminder</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700">Notes</label>
                  <input
                    type="text"
                    value={newFollowUpNotes}
                    onChange={(e) => setNewFollowUpNotes(e.target.value)}
                    placeholder="Discussion agenda..."
                    className="w-full rounded border border-slate-300 p-1.5"
                  />
                </div>

                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddFollowUp(false)}
                    className="rounded px-2.5 py-1 text-slate-600 hover:bg-slate-200"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="rounded bg-emerald-800 px-3 py-1 font-semibold text-white hover:bg-emerald-900"
                  >
                    Save Reminder
                  </button>
                </div>
              </form>
            )}

            {clientFollowUps.length === 0 ? (
              <p className="text-xs text-slate-400 py-1 italic">No pending follow-ups for this client.</p>
            ) : (
              <div className="space-y-2">
                {clientFollowUps.map((f) => (
                  <div
                    key={f.id}
                    className="rounded-lg border border-slate-100 bg-slate-50/50 p-2.5 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-semibold text-slate-800">
                        {f.type} • {f.dueDate} at {f.dueTime}
                      </div>
                      <p className="text-[11px] text-slate-500">{f.notes}</p>
                    </div>
                    <span
                      className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${
                        f.status === 'Overdue'
                          ? 'bg-rose-100 text-rose-800'
                          : f.status === 'Completed'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {f.status}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Notes & Activity Timeline */}
          <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
            <h4 className="font-bold text-xs text-slate-900 border-b border-slate-100 pb-2">
              Interaction Log & Call Notes
            </h4>
            <div className="rounded-lg bg-slate-50 border border-slate-200 p-3 text-xs text-slate-700 whitespace-pre-wrap font-sans max-h-40 overflow-y-auto">
              {client.notes || 'No notes added yet.'}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={newNote}
                onChange={(e) => setNewNote(e.target.value)}
                placeholder="Add conversation note or client request..."
                className="flex-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs focus:border-emerald-600 focus:outline-none"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleAppendNote();
                }}
              />
              <button
                onClick={handleAppendNote}
                className="rounded-lg bg-emerald-800 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-900"
              >
                Log Note
              </button>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="border-t border-slate-200 bg-slate-50 p-4 flex items-center justify-between">
          <div>
            {client.archived ? (
              <button
                onClick={() => restoreClient(client.id)}
                className="flex items-center gap-1.5 rounded-lg border border-emerald-300 bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-800 hover:bg-emerald-100"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span>Restore Client</span>
              </button>
            ) : (
              <button
                onClick={() => archiveClient(client.id)}
                className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-100"
              >
                <Archive className="h-3.5 w-3.5" />
                <span>Archive Record</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                toggleSelectClient(client.id);
              }}
              className={`rounded-lg px-3 py-1.5 text-xs font-semibold border transition-colors ${
                isSelected
                  ? 'border-emerald-600 bg-emerald-50 text-emerald-800'
                  : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
              }`}
            >
              {isSelected ? '✓ In Campaign Queue' : '+ Add to Campaign'}
            </button>
            <button
              onClick={() => onEdit(client)}
              className="rounded-lg bg-emerald-800 px-4 py-1.5 text-xs font-semibold text-white hover:bg-emerald-900"
            >
              Edit Details
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
