import React from 'react';
import { ShieldCheck, ShieldAlert, FileText, UserCheck, Clock, Download, Upload, Send } from 'lucide-react';
import { useCrm } from '../context/CrmContext';

export const AuditLogsView: React.FC = () => {
  const { auditLogs, currentRole } = useCrm();

  return (
    <div className="space-y-6">
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-emerald-800" />
            <span>Compliance & Audit Trail</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Immutable system logs for Excel client imports, database exports, WhatsApp marketing campaigns, and opt-out requests.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="rounded bg-slate-100 text-slate-700 px-2.5 py-1 text-xs font-semibold">
            Active Session Role: <strong>{currentRole}</strong>
          </span>
        </div>
      </div>

      {/* Role-based permissions matrix summary */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
        <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
          Role-Based Access Control (RBAC) Architecture
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="rounded-lg bg-emerald-50/50 border border-emerald-200 p-3">
            <span className="font-bold text-emerald-900 block">Super Admin (Director)</span>
            <p className="text-[11px] text-emerald-800 mt-1">
              Full access: Client creation, Excel import/export, WhatsApp Cloud API keys, launch broadcast campaigns, archive/delete records.
            </p>
          </div>
          <div className="rounded-lg bg-blue-50/50 border border-blue-200 p-3">
            <span className="font-bold text-blue-900 block">Manager (Sales Head)</span>
            <p className="text-[11px] text-blue-800 mt-1">
              Team oversight: Manage client assignments, export filtered client lists, create campaign drafts, approve site visits.
            </p>
          </div>
          <div className="rounded-lg bg-amber-50/50 border border-amber-200 p-3">
            <span className="font-bold text-amber-900 block">Sales Executive</span>
            <p className="text-[11px] text-amber-800 mt-1">
              Field operational access: Update client call notes, schedule follow-ups and site visits, chat with assigned clients.
            </p>
          </div>
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="rounded-xl border border-slate-200 bg-white shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100">
          <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            System Event Log ({auditLogs.length} events recorded)
          </h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold text-[11px]">
              <tr>
                <th className="py-2.5 px-3">Event Time</th>
                <th className="py-2.5 px-3">User & Role</th>
                <th className="py-2.5 px-3">Action Type</th>
                <th className="py-2.5 px-3">Event Description</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
              {auditLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50">
                  <td className="py-2.5 px-3 text-slate-500 whitespace-nowrap">{log.timestamp}</td>
                  <td className="py-2.5 px-3 font-sans">
                    <span className="font-bold text-slate-800 block text-xs">{log.user}</span>
                    <span className="text-[10px] text-slate-500 font-mono">[{log.role}]</span>
                  </td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`inline-block rounded px-2 py-0.5 text-[10px] font-bold font-sans ${
                        log.action === 'IMPORT'
                          ? 'bg-blue-100 text-blue-800'
                          : log.action === 'EXPORT'
                          ? 'bg-purple-100 text-purple-800'
                          : log.action === 'CAMPAIGN_LAUNCH'
                          ? 'bg-emerald-100 text-emerald-800'
                          : log.action === 'OPT_OUT'
                          ? 'bg-amber-100 text-amber-800'
                          : log.action === 'CLIENT_DELETE'
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {log.action}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 font-sans text-slate-700 text-xs">{log.details}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
