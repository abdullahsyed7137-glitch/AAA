import React, { useState } from 'react';
import {
  CalendarClock,
  Clock,
  AlertTriangle,
  CheckCircle2,
  CalendarCheck,
  Plus,
  Phone,
  MessageSquare,
  Building,
  User,
  MapPin,
  Check,
  X,
  FileText,
} from 'lucide-react';
import { useCrm } from '../context/CrmContext';
import { FollowUp, SiteVisit } from '../types';
import { formatIndianMobileDisplay, toWhatsAppApiFormat } from '../utils/clientValidation';
import { LUCKNOW_PROJECTS } from '../data/seedData';

export const FollowUpManagementView: React.FC = () => {
  const {
    followUps,
    siteVisits,
    clients,
    updateFollowUp,
    addFollowUp,
    updateSiteVisit,
    addSiteVisit,
  } = useCrm();

  const [activeTabSub, setActiveTabSub] = useState<'followups' | 'sitevisits'>('followups');
  const [filterType, setFilterType] = useState<string>('ALL');

  // Form states
  const [showAddFollowUpModal, setShowAddFollowUpModal] = useState(false);
  const [showAddVisitModal, setShowAddVisitModal] = useState(false);

  // New Follow-up fields
  const [selectedClientId, setSelectedClientId] = useState(clients[0]?.id || '');
  const [followUpDate, setFollowUpDate] = useState(new Date().toISOString().split('T')[0]);
  const [followUpTime, setFollowUpTime] = useState('11:30');
  const [followUpType, setFollowUpType] = useState<any>('Call');
  const [followUpNotes, setFollowUpNotes] = useState('');

  // New Site Visit fields
  const [visitClientId, setVisitClientId] = useState(clients[0]?.id || '');
  const [visitProject, setVisitProject] = useState('HM Royal Palms, Gomti Nagar Ext.');
  const [visitPropertyType, setVisitPropertyType] = useState('3 BHK Premium Flat');
  const [visitDate, setVisitDate] = useState(new Date().toISOString().split('T')[0]);
  const [visitTime, setVisitTime] = useState('11:00 AM');
  const [visitFeedback, setVisitFeedback] = useState('');

  const overdueList = followUps.filter((f) => f.status === 'Overdue');
  const pendingList = followUps.filter((f) => f.status === 'Pending');
  const completedList = followUps.filter((f) => f.status === 'Completed');

  const handleMarkFollowUpDone = (f: FollowUp) => {
    updateFollowUp({
      ...f,
      status: 'Completed',
      completedAt: new Date().toISOString(),
      outcome: 'Follow-up discussion concluded successfully',
    });
  };

  const handleCreateFollowUp = (e: React.FormEvent) => {
    e.preventDefault();
    const cl = clients.find((c) => c.id === selectedClientId);
    if (!cl) return;

    addFollowUp({
      clientId: cl.id,
      clientName: cl.name,
      clientMobile: cl.mobile,
      assignedExecutive: cl.assignedExecutive,
      dueDate: followUpDate,
      dueTime: followUpTime,
      type: followUpType,
      status: 'Pending',
      projectName: cl.projectName,
      notes: followUpNotes || 'Scheduled client reminder',
    });

    setShowAddFollowUpModal(false);
    setFollowUpNotes('');
  };

  const handleCreateSiteVisit = (e: React.FormEvent) => {
    e.preventDefault();
    const cl = clients.find((c) => c.id === visitClientId);
    if (!cl) return;

    addSiteVisit({
      clientId: cl.id,
      clientName: cl.name,
      clientMobile: cl.mobile,
      projectName: visitProject,
      propertyInterest: visitPropertyType,
      visitDate,
      visitTime,
      assignedExecutive: cl.assignedExecutive,
      status: 'Scheduled',
      feedback: visitFeedback || 'Site inspection booked',
    });

    setShowAddVisitModal(false);
    setVisitFeedback('');
  };

  return (
    <div className="space-y-6">
      {/* Title & Actions */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <CalendarClock className="h-5 w-5 text-emerald-800" />
            <span>Client Follow-up & Site Visit Management</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Track call notes, upcoming Lucknow project walkthroughs, and buyer commitments.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddFollowUpModal(true)}
            className="flex items-center gap-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 px-3.5 py-1.5 text-xs font-semibold text-white shadow-xs"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Schedule Follow-up</span>
          </button>

          <button
            onClick={() => setShowAddVisitModal(true)}
            className="flex items-center gap-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 px-3.5 py-1.5 text-xs font-semibold text-white shadow-xs"
          >
            <CalendarCheck className="h-3.5 w-3.5" />
            <span>Schedule Site Visit</span>
          </button>
        </div>
      </div>

      {/* Tabs: Follow-ups vs Site Visits */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTabSub('followups')}
          className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-bold transition-all ${
            activeTabSub === 'followups'
              ? 'bg-emerald-800 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Clock className="h-4 w-4" />
          <span>Follow-up Reminders ({followUps.length})</span>
          {overdueList.length > 0 && (
            <span className="rounded bg-rose-500 text-white px-1.5 py-0.2 text-[10px]">
              {overdueList.length} Overdue
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTabSub('sitevisits')}
          className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-bold transition-all ${
            activeTabSub === 'sitevisits'
              ? 'bg-emerald-800 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <CalendarCheck className="h-4 w-4" />
          <span>Site Visits Scheduled ({siteVisits.length})</span>
        </button>
      </div>

      {activeTabSub === 'followups' ? (
        <div className="space-y-6">
          {/* Overdue Warnings */}
          {overdueList.length > 0 && (
            <div className="rounded-xl border border-rose-300 bg-rose-50/80 p-4 space-y-3">
              <div className="flex items-center gap-2 text-rose-900 font-bold text-xs uppercase tracking-wider">
                <AlertTriangle className="h-4 w-4 text-rose-600" />
                <span>Overdue Follow-ups Requiring Immediate Attention ({overdueList.length})</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {overdueList.map((item) => (
                  <div
                    key={item.id}
                    className="rounded-lg border border-rose-200 bg-white p-3 shadow-xs space-y-2 text-xs"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="font-bold text-slate-900 block">{item.clientName}</span>
                        <span className="text-[11px] text-slate-500">
                          {item.projectName} • {item.type}
                        </span>
                      </div>
                      <span className="rounded bg-rose-100 text-rose-800 px-2 py-0.5 text-[10px] font-bold">
                        Due: {item.dueDate}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-700 bg-slate-50 p-2 rounded border border-slate-100">
                      {item.notes}
                    </p>

                    <div className="flex items-center justify-between pt-1">
                      <span className="text-[11px] text-slate-500">
                        Executive: <strong>{item.assignedExecutive}</strong>
                      </span>
                      <div className="flex items-center gap-2">
                        <a
                          href={`https://wa.me/${toWhatsAppApiFormat(item.clientMobile)}`}
                          target="_blank"
                          rel="noreferrer"
                          className="rounded p-1 text-emerald-700 hover:bg-emerald-50"
                          title="WhatsApp"
                        >
                          <MessageSquare className="h-4 w-4" />
                        </a>
                        <button
                          onClick={() => handleMarkFollowUpDone(item)}
                          className="rounded bg-emerald-700 text-white px-2.5 py-1 text-[11px] font-semibold hover:bg-emerald-800 flex items-center gap-1"
                        >
                          <Check className="h-3 w-3" />
                          <span>Mark Done</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Pending Follow-ups */}
          <div className="rounded-xl border border-slate-200 bg-white shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100">
              <h3 className="font-bold text-xs uppercase text-slate-800">
                Scheduled Follow-up Pipeline ({pendingList.length})
              </h3>
            </div>

            <div className="divide-y divide-slate-100">
              {pendingList.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs">
                  No upcoming follow-ups scheduled. Click 'Schedule Follow-up' to create one.
                </div>
              ) : (
                pendingList.map((f) => (
                  <div
                    key={f.id}
                    className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50 text-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-sm">{f.clientName}</span>
                        <span className="font-mono text-slate-500 text-[11px]">
                          ({formatIndianMobileDisplay(f.clientMobile)})
                        </span>
                        <span className="rounded bg-slate-100 text-slate-700 px-2 py-0.5 text-[10px] font-semibold">
                          {f.type}
                        </span>
                      </div>
                      <p className="text-slate-600 text-xs">
                        Project: <strong>{f.projectName}</strong> • Executive:{' '}
                        <strong>{f.assignedExecutive}</strong>
                      </p>
                      <p className="text-[11px] text-slate-500 italic">"{f.notes}"</p>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <span className="font-bold text-slate-800 block">{f.dueDate}</span>
                        <span className="text-[11px] text-slate-500">{f.dueTime}</span>
                      </div>

                      <button
                        onClick={() => handleMarkFollowUpDone(f)}
                        className="rounded-lg bg-emerald-800 text-white px-3 py-1.5 text-xs font-semibold hover:bg-emerald-900 flex items-center gap-1 shadow-xs"
                      >
                        <Check className="h-3.5 w-3.5" />
                        <span>Complete</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      ) : (
        /* Site Visits View */
        <div className="rounded-xl border border-slate-200 bg-white shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-100">
            <h3 className="font-bold text-xs uppercase text-slate-800">
              Site Visits & Experience Center Appointments
            </h3>
          </div>

          <div className="divide-y divide-slate-100">
            {siteVisits.map((v) => (
              <div
                key={v.id}
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 text-sm">{v.clientName}</span>
                    <span className="font-mono text-slate-500 text-[11px]">
                      ({formatIndianMobileDisplay(v.clientMobile)})
                    </span>
                    <span
                      className={`rounded px-2 py-0.5 text-[10px] font-bold ${
                        v.status === 'Completed'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {v.status}
                    </span>
                  </div>

                  <div className="text-slate-600 flex items-center gap-2 mt-1">
                    <MapPin className="h-3.5 w-3.5 text-amber-600 shrink-0" />
                    <span>
                      {v.projectName} • {v.propertyInterest}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-500 mt-1">Feedback / Notes: {v.feedback}</p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="font-bold text-slate-800 block">{v.visitDate}</span>
                    <span className="text-[11px] text-slate-500">{v.visitTime}</span>
                  </div>

                  {v.status !== 'Completed' && (
                    <button
                      onClick={() =>
                        updateSiteVisit({
                          ...v,
                          status: 'Completed',
                          feedback: `${v.feedback} [Completed on time - Client satisfied]`,
                        })
                      }
                      className="rounded-lg bg-emerald-800 text-white px-3 py-1.5 text-xs font-semibold hover:bg-emerald-900 flex items-center gap-1"
                    >
                      <Check className="h-3.5 w-3.5" />
                      <span>Mark Visit Complete</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Schedule Follow-up Modal */}
      {showAddFollowUpModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-md rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between border-b border-slate-100 bg-emerald-950 px-5 py-4 text-white">
              <h3 className="font-bold text-sm">Schedule Client Follow-up</h3>
              <button
                onClick={() => setShowAddFollowUpModal(false)}
                className="text-slate-300 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleCreateFollowUp} className="p-5 space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Select Client *</label>
                <select
                  value={selectedClientId}
                  onChange={(e) => setSelectedClientId(e.target.value)}
                  className="w-full rounded border border-slate-300 p-2"
                >
                  {clients.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.projectName} - {c.mobile})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Date *</label>
                  <input
                    type="date"
                    required
                    value={followUpDate}
                    onChange={(e) => setFollowUpDate(e.target.value)}
                    className="w-full rounded border border-slate-300 p-2"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Time</label>
                  <input
                    type="time"
                    value={followUpTime}
                    onChange={(e) => setFollowUpTime(e.target.value)}
                    className="w-full rounded border border-slate-300 p-2"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Follow-up Type</label>
                <select
                  value={followUpType}
                  onChange={(e) => setFollowUpType(e.target.value)}
                  className="w-full rounded border border-slate-300 p-2"
                >
                  <option value="Call">Call</option>
                  <option value="Site Visit">Site Visit</option>
                  <option value="Meeting">Meeting</option>
                  <option value="WhatsApp Reminder">WhatsApp Reminder</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Agenda / Notes</label>
                <textarea
                  rows={2}
                  value={followUpNotes}
                  onChange={(e) => setFollowUpNotes(e.target.value)}
                  placeholder="e.g. Unit layout discussion and bank loan details..."
                  className="w-full rounded border border-slate-300 p-2"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddFollowUpModal(false)}
                  className="rounded border border-slate-300 px-3 py-1.5 text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded bg-emerald-800 text-white px-4 py-1.5 font-semibold hover:bg-emerald-900"
                >
                  Save Reminder
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Schedule Site Visit Modal */}
      {showAddVisitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-md rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between border-b border-slate-100 bg-amber-600 px-5 py-4 text-white">
              <h3 className="font-bold text-sm">Schedule Project Site Visit</h3>
              <button
                onClick={() => setShowAddVisitModal(false)}
                className="text-amber-100 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleCreateSiteVisit} className="p-5 space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Select Client *</label>
                <select
                  value={visitClientId}
                  onChange={(e) => setVisitClientId(e.target.value)}
                  className="w-full rounded border border-slate-300 p-2"
                >
                  {clients.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.mobile})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Lucknow Project *</label>
                <select
                  value={visitProject}
                  onChange={(e) => setVisitProject(e.target.value)}
                  className="w-full rounded border border-slate-300 p-2"
                >
                  {LUCKNOW_PROJECTS.map((p) => (
                    <option key={p.id} value={`${p.name}, ${p.location}`}>
                      {p.name} - {p.location}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Visit Date *</label>
                  <input
                    type="date"
                    required
                    value={visitDate}
                    onChange={(e) => setVisitDate(e.target.value)}
                    className="w-full rounded border border-slate-300 p-2"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Visit Time *</label>
                  <input
                    type="text"
                    required
                    value={visitTime}
                    onChange={(e) => setVisitTime(e.target.value)}
                    placeholder="11:30 AM"
                    className="w-full rounded border border-slate-300 p-2"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Arrangements / Pick-up Notes
                </label>
                <textarea
                  rows={2}
                  value={visitFeedback}
                  onChange={(e) => setVisitFeedback(e.target.value)}
                  placeholder="e.g. Car pickup arranged from Hazratganj office. Visiting with family."
                  className="w-full rounded border border-slate-300 p-2"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddVisitModal(false)}
                  className="rounded border border-slate-300 px-3 py-1.5 text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded bg-amber-600 text-white px-4 py-1.5 font-semibold hover:bg-amber-700"
                >
                  Book Site Visit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
