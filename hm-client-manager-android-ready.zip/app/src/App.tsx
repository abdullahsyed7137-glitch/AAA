/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CrmProvider, useCrm } from './context/CrmContext';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { ClientManagementView } from './components/ClientManagementView';
import { ClientSegmentationView } from './components/ClientSegmentationView';
import { WhatsAppCampaignView } from './components/WhatsAppCampaignView';
import { CampaignReportsView } from './components/CampaignReportsView';
import { FollowUpManagementView } from './components/FollowUpManagementView';
import { TemplateManagementView } from './components/TemplateManagementView';
import { AuditLogsView } from './components/AuditLogsView';
import { ClientDetailModal } from './components/ClientDetailModal';
import { ClientDetailDrawer } from './components/ClientDetailDrawer';
import { ExcelImportModal } from './components/ExcelImportModal';
import { WhatsAppSettingsModal } from './components/WhatsAppSettingsModal';
import { Client } from './types';
import {
  LayoutDashboard,
  Users,
  Filter,
  Send,
  BarChart3,
  CalendarClock,
  Settings,
} from 'lucide-react';

const MainLayout: React.FC = () => {
  const { activeTab, setActiveTab, addClient, updateClient } = useCrm();

  const [isAddClientOpen, setIsAddClientOpen] = useState(false);
  const [isEditClientOpen, setIsEditClientOpen] = useState(false);
  const [selectedClientForEdit, setSelectedClientForEdit] = useState<Client | null>(null);

  const [viewingClient, setViewingClient] = useState<Client | null>(null);
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const handleOpenEdit = (client: Client) => {
    setSelectedClientForEdit(client);
    setIsEditClientOpen(true);
  };

  const handleSaveNewClient = (clientData: any) => {
    addClient(clientData);
  };

  const handleSaveEditClient = (clientData: Client) => {
    updateClient(clientData);
    if (viewingClient && viewingClient.id === clientData.id) {
      setViewingClient(clientData);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 flex flex-col font-sans antialiased selection:bg-emerald-100 selection:text-emerald-900">
      {/* Top Header */}
      <Header
        onOpenAddClient={() => setIsAddClientOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* Main Container */}
      <div className="flex flex-1">
        {/* Desktop Sidebar */}
        <Sidebar onOpenSettings={() => setIsSettingsOpen(true)} />

        {/* Viewport Content Area */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full pb-20 md:pb-8">
          {activeTab === 'dashboard' && (
            <DashboardView
              onOpenAddClient={() => setIsAddClientOpen(true)}
              onOpenImport={() => setIsImportOpen(true)}
            />
          )}

          {activeTab === 'clients' && (
            <ClientManagementView
              onOpenAddClient={() => setIsAddClientOpen(true)}
              onOpenImport={() => setIsImportOpen(true)}
              onViewClient={(c) => setViewingClient(c)}
              onEditClient={handleOpenEdit}
            />
          )}

          {activeTab === 'segmentation' && <ClientSegmentationView />}

          {activeTab === 'campaign-builder' && <WhatsAppCampaignView />}

          {activeTab === 'campaign-reports' && <CampaignReportsView />}

          {activeTab === 'follow-ups' && <FollowUpManagementView />}

          {activeTab === 'templates' && <TemplateManagementView />}

          {activeTab === 'audit' && <AuditLogsView />}
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 flex items-center justify-around py-2 px-1 text-[10px] font-semibold text-slate-600 shadow-lg">
        {[
          { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
          { id: 'clients', label: 'Clients', icon: Users },
          { id: 'segmentation', label: 'Filters', icon: Filter },
          { id: 'campaign-builder', label: 'Campaign', icon: Send },
          { id: 'campaign-reports', label: 'Reports', icon: BarChart3 },
          { id: 'follow-ups', label: 'Follow-ups', icon: CalendarClock },
        ].map((m) => {
          const Icon = m.icon;
          const isActive = activeTab === m.id;
          return (
            <button
              key={m.id}
              onClick={() => setActiveTab(m.id)}
              className={`flex flex-col items-center gap-0.5 px-2 py-1 rounded transition-colors ${
                isActive ? 'text-emerald-800 font-bold' : 'text-slate-500'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{m.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Add Client Modal */}
      <ClientDetailModal
        isOpen={isAddClientOpen}
        onClose={() => setIsAddClientOpen(false)}
        onSave={handleSaveNewClient}
        mode="add"
      />

      {/* Edit Client Modal */}
      <ClientDetailModal
        isOpen={isEditClientOpen}
        onClose={() => {
          setIsEditClientOpen(false);
          setSelectedClientForEdit(null);
        }}
        initialData={selectedClientForEdit}
        onSave={handleSaveEditClient}
        mode="edit"
      />

      {/* Client Detail Drawer */}
      <ClientDetailDrawer
        client={viewingClient}
        onClose={() => setViewingClient(null)}
        onEdit={(c) => {
          setViewingClient(null);
          handleOpenEdit(c);
        }}
      />

      {/* Excel/CSV Import Modal */}
      <ExcelImportModal
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
      />

      {/* WhatsApp Cloud API Settings & Guide Modal */}
      <WhatsAppSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <CrmProvider>
      <MainLayout />
    </CrmProvider>
  );
}
