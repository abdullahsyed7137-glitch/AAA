import { API_BASE } from '../utils/api';
import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Client,
  FollowUp,
  SiteVisit,
  WhatsAppCampaign,
  WhatsAppTemplate,
  AuditLog,
  UserRole,
  WhatsAppConfig,
} from '../types';
import {
  INITIAL_CLIENTS,
  INITIAL_TEMPLATES,
  INITIAL_CAMPAIGNS,
  INITIAL_FOLLOW_UPS,
  INITIAL_SITE_VISITS,
  INITIAL_AUDIT_LOGS,
} from '../data/seedData';
import { exportClientsToExcel } from '../utils/excelHelper';
import { toWhatsAppApiFormat } from '../utils/clientValidation';

interface CrmContextType {
  clients: Client[];
  followUps: FollowUp[];
  siteVisits: SiteVisit[];
  campaigns: WhatsAppCampaign[];
  templates: WhatsAppTemplate[];
  auditLogs: AuditLog[];
  currentRole: UserRole;
  activeTab: string;
  apiConfig: WhatsAppConfig;
  selectedClientIds: string[];
  searchQuery: string;
  
  // Setters & Actions
  setCurrentRole: (role: UserRole) => void;
  setActiveTab: (tab: string) => void;
  setSearchQuery: (query: string) => void;
  addClient: (client: Omit<Client, 'id' | 'createdAt' | 'updatedAt'>) => Client;
  updateClient: (client: Client) => void;
  archiveClient: (id: string) => void;
  restoreClient: (id: string) => void;
  deleteClient: (id: string) => void;
  importClientsWithDuplicates: (
    validClients: Partial<Client>[],
    duplicateAction: 'skip' | 'overwrite' | 'merge',
    duplicates: Array<{ candidate: Partial<Client>; existing: any }>
  ) => void;
  exportClients: (clientsToExport?: Client[]) => void;
  toggleSelectClient: (id: string) => void;
  selectAllClients: (ids: string[]) => void;
  clearSelection: () => void;
  createCampaign: (campaign: Omit<WhatsAppCampaign, 'id' | 'createdAt' | 'acceptedByApi' | 'deliveredCount' | 'readCount' | 'failedCount' | 'recipients'>) => WhatsAppCampaign;
  launchCampaign: (campaignId: string) => Promise<{ success: boolean; message: string; metaLogs?: any }>;
  addFollowUp: (followUp: Omit<FollowUp, 'id'>) => void;
  updateFollowUp: (followUp: FollowUp) => void;
  addSiteVisit: (siteVisit: Omit<SiteVisit, 'id'>) => void;
  updateSiteVisit: (siteVisit: SiteVisit) => void;
  addTemplate: (template: Omit<WhatsAppTemplate, 'id'>) => void;
  refreshApiStatus: () => Promise<void>;
  addAuditLog: (action: AuditLog['action'], details: string) => void;
}

const CrmContext = createContext<CrmContextType | undefined>(undefined);

const STORAGE_KEYS = {
  CLIENTS: 'hm_clients_v2',
  FOLLOW_UPS: 'hm_followups_v2',
  SITE_VISITS: 'hm_sitevisits_v2',
  CAMPAIGNS: 'hm_campaigns_v2',
  TEMPLATES: 'hm_templates_v2',
  LOGS: 'hm_auditlogs_v2',
  ROLE: 'hm_user_role_v2',
};

export const CrmProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [clients, setClients] = useState<Client[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CLIENTS);
    return saved ? JSON.parse(saved) : INITIAL_CLIENTS;
  });

  const [followUps, setFollowUps] = useState<FollowUp[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.FOLLOW_UPS);
    return saved ? JSON.parse(saved) : INITIAL_FOLLOW_UPS;
  });

  const [siteVisits, setSiteVisits] = useState<SiteVisit[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SITE_VISITS);
    return saved ? JSON.parse(saved) : INITIAL_SITE_VISITS;
  });

  const [campaigns, setCampaigns] = useState<WhatsAppCampaign[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CAMPAIGNS);
    return saved ? JSON.parse(saved) : INITIAL_CAMPAIGNS;
  });

  const [templates, setTemplates] = useState<WhatsAppTemplate[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.TEMPLATES);
    return saved ? JSON.parse(saved) : INITIAL_TEMPLATES;
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.LOGS);
    return saved ? JSON.parse(saved) : INITIAL_AUDIT_LOGS;
  });

  const [currentRole, setCurrentRoleState] = useState<UserRole>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ROLE);
    return (saved as UserRole) || 'Super Admin';
  });

  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [selectedClientIds, setSelectedClientIds] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const [apiConfig, setApiConfig] = useState<WhatsAppConfig>({
    phoneNumberId: '',
    businessAccountId: '',
    hasToken: false,
    webhookVerifyToken: 'hm_group_lucknow_crm_2025',
    isConfigured: false,
  });

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CLIENTS, JSON.stringify(clients));
  }, [clients]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.FOLLOW_UPS, JSON.stringify(followUps));
  }, [followUps]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SITE_VISITS, JSON.stringify(siteVisits));
  }, [siteVisits]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CAMPAIGNS, JSON.stringify(campaigns));
  }, [campaigns]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TEMPLATES, JSON.stringify(templates));
  }, [templates]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(auditLogs));
  }, [auditLogs]);

  const setCurrentRole = (role: UserRole) => {
    setCurrentRoleState(role);
    localStorage.setItem(STORAGE_KEYS.ROLE, role);
    addAuditLog('CLIENT_UPDATE', `User switched active role to ${role}`);
  };

  const addAuditLog = (action: AuditLog['action'], details: string) => {
    const newLog: AuditLog = {
      id: `LOG-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      user: currentRole === 'Super Admin' ? 'Abdullah Syed (Director)' : currentRole === 'Manager' ? 'Neha Sharma (Sales Head)' : 'Tariq Ansari (Executive)',
      role: currentRole,
      action,
      details,
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  // Check backend WhatsApp status
  const refreshApiStatus = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/whatsapp/status`);
      if (res.ok) {
        const data = await res.json();
        setApiConfig({
          phoneNumberId: data.phoneNumberId || '',
          businessAccountId: data.businessAccountId || '',
          hasToken: data.hasToken || false,
          webhookVerifyToken: data.webhookVerifyToken || 'hm_group_lucknow_crm_2025',
          isConfigured: data.isConfigured || false,
        });
      }
    } catch {
      // Backend status fallback
      setApiConfig((prev) => ({ ...prev, isConfigured: false }));
    }
  };

  useEffect(() => {
    refreshApiStatus();
  }, []);

  const addClient = (data: Omit<Client, 'id' | 'createdAt' | 'updatedAt'>): Client => {
    const newId = `HM-2025-0${100 + clients.length + 1}`;
    const now = new Date().toISOString();
    const newClient: Client = {
      ...data,
      id: newId,
      createdAt: now,
      updatedAt: now,
    };
    setClients((prev) => [newClient, ...prev]);
    addAuditLog('CLIENT_CREATE', `Created new client: ${newClient.name} (${newClient.id})`);
    return newClient;
  };

  const updateClient = (updated: Client) => {
    const now = new Date().toISOString();
    setClients((prev) =>
      prev.map((c) => (c.id === updated.id ? { ...updated, updatedAt: now } : c))
    );
    addAuditLog('CLIENT_UPDATE', `Updated client profile: ${updated.name} (${updated.id})`);
  };

  const archiveClient = (id: string) => {
    setClients((prev) =>
      prev.map((c) => (c.id === id ? { ...c, archived: true, updatedAt: new Date().toISOString() } : c))
    );
    addAuditLog('CLIENT_DELETE', `Archived client ID: ${id}`);
  };

  const restoreClient = (id: string) => {
    setClients((prev) =>
      prev.map((c) => (c.id === id ? { ...c, archived: false, updatedAt: new Date().toISOString() } : c))
    );
    addAuditLog('CLIENT_UPDATE', `Restored archived client ID: ${id}`);
  };

  const deleteClient = (id: string) => {
    setClients((prev) => prev.filter((c) => c.id !== id));
    addAuditLog('CLIENT_DELETE', `Permanently deleted client ID: ${id}`);
  };

  const importClientsWithDuplicates = (
    validClients: Partial<Client>[],
    duplicateAction: 'skip' | 'overwrite' | 'merge',
    duplicates: Array<{ candidate: Partial<Client>; existing: any }>
  ) => {
    const now = new Date().toISOString();
    let updatedList = [...clients];
    let addedCount = 0;
    let modifiedCount = 0;

    // 1. Process valid non-duplicate entries
    for (const valid of validClients) {
      const newId = `HM-2025-0${100 + updatedList.length + 1}`;
      const newRecord: Client = {
        id: valid.id || newId,
        name: valid.name || 'Unnamed Client',
        mobile: valid.mobile || '',
        whatsappNumber: valid.whatsappNumber || valid.mobile || '',
        city: valid.city || 'Lucknow',
        propertyInterest: valid.propertyInterest || '2 BHK Luxury Apartment',
        projectName: valid.projectName || 'HM Royal Palms',
        budget: valid.budget || '₹50 - ₹75 Lakhs',
        leadSource: valid.leadSource || 'Excel Import',
        leadStatus: (valid.leadStatus as any) || 'New Lead',
        assignedExecutive: valid.assignedExecutive || 'Tariq Ansari',
        lastContactDate: valid.lastContactDate || now.split('T')[0],
        nextFollowUpDate: valid.nextFollowUpDate || '',
        notes: valid.notes || 'Imported via Excel spreadsheet',
        whatsappConsent: (valid.whatsappConsent as any) || 'Opted-in',
        archived: false,
        createdAt: now,
        updatedAt: now,
      };
      updatedList.unshift(newRecord);
      addedCount++;
    }

    // 2. Process duplicates based on user choice
    if (duplicateAction === 'overwrite') {
      for (const dup of duplicates) {
        const existingIdx = updatedList.findIndex((c) => c.id === dup.existing.id);
        if (existingIdx !== -1) {
          updatedList[existingIdx] = {
            ...updatedList[existingIdx],
            ...dup.candidate,
            id: dup.existing.id,
            updatedAt: now,
          } as Client;
          modifiedCount++;
        }
      }
    } else if (duplicateAction === 'merge') {
      for (const dup of duplicates) {
        const existingIdx = updatedList.findIndex((c) => c.id === dup.existing.id);
        if (existingIdx !== -1) {
          const current = updatedList[existingIdx];
          updatedList[existingIdx] = {
            ...current,
            propertyInterest: dup.candidate.propertyInterest || current.propertyInterest,
            projectName: dup.candidate.projectName || current.projectName,
            budget: dup.candidate.budget || current.budget,
            notes: `${current.notes}\n[Imported Update]: ${dup.candidate.notes || ''}`.trim(),
            updatedAt: now,
          };
          modifiedCount++;
        }
      }
    }

    setClients(updatedList);
    addAuditLog(
      'IMPORT',
      `Imported client records: ${addedCount} added, ${modifiedCount} ${duplicateAction}d from duplicates`
    );
  };

  const exportClients = (clientsToExport?: Client[]) => {
    const list = clientsToExport || clients;
    exportClientsToExcel(list, `HM_Group_Clients_${new Date().toISOString().split('T')[0]}.xlsx`);
    addAuditLog('EXPORT', `Exported ${list.length} clients to Excel`);
  };

  const toggleSelectClient = (id: string) => {
    setSelectedClientIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const selectAllClients = (ids: string[]) => {
    setSelectedClientIds(ids);
  };

  const clearSelection = () => {
    setSelectedClientIds([]);
  };

  const createCampaign = (
    campaignData: Omit<
      WhatsAppCampaign,
      'id' | 'createdAt' | 'acceptedByApi' | 'deliveredCount' | 'readCount' | 'failedCount' | 'recipients'
    >
  ): WhatsAppCampaign => {
    const id = `CMP-${Date.now().toString().slice(-6)}`;
    const newCampaign: WhatsAppCampaign = {
      ...campaignData,
      id,
      createdAt: new Date().toISOString(),
      acceptedByApi: 0,
      deliveredCount: 0,
      readCount: 0,
      failedCount: 0,
      recipients: [],
    };
    setCampaigns((prev) => [newCampaign, ...prev]);
    addAuditLog('CAMPAIGN_LAUNCH', `Created campaign draft: ${newCampaign.name}`);
    return newCampaign;
  };

  const launchCampaign = async (campaignId: string): Promise<{ success: boolean; message: string }> => {
    const campaign = campaigns.find((c) => c.id === campaignId);
    if (!campaign) {
      return { success: false, message: 'Campaign not found' };
    }

    // Get audience
    const targetClients = clients.filter(
      (c) => selectedClientIds.includes(c.id) || campaign.recipients.some((r) => r.clientId === c.id)
    );

    // If WhatsApp Cloud API credentials are NOT configured on backend:
    // Important requirement: "Do not simulate successful WhatsApp delivery. If WhatsApp credentials are missing, show a clear setup status."
    if (!apiConfig.isConfigured) {
      addAuditLog(
        'CAMPAIGN_LAUNCH',
        `Attempted launch of "${campaign.name}" blocked: WhatsApp Business Cloud API credentials not configured.`
      );
      return {
        success: false,
        message: 'WhatsApp Business Cloud API credentials are not configured in your backend environment. Please configure WHATSAPP_ACCESS_TOKEN and WHATSAPP_PHONE_NUMBER_ID in the API Settings.',
      };
    }

    // If configured, trigger official WhatsApp Cloud API through backend proxy
    const recipientLogs: any[] = [];
    let accepted = 0;
    let failed = 0;

    for (const client of targetClients) {
      if (client.whatsappConsent === 'Opted-out') {
        recipientLogs.push({
          clientId: client.id,
          clientName: client.name,
          whatsappNumber: toWhatsAppApiFormat(client.whatsappNumber || client.mobile),
          status: 'Opted-Out' as const,
          errorMessage: 'Excluded: Client has opted out of marketing communications',
        });
        continue;
      }

      try {
        const payload: any = {
          to: toWhatsAppApiFormat(client.whatsappNumber || client.mobile),
          recipientName: client.name,
        };

        if (campaign.messageType === 'Template') {
          payload.type = 'template';
          payload.template = {
            name: campaign.templateId || 'hm_project_launch_offer',
            language: 'en_US',
            components: [
              {
                type: 'body',
                parameters: [
                  { type: 'text', text: client.name },
                  { type: 'text', text: client.projectName },
                  { type: 'text', text: client.assignedExecutive },
                ],
              },
            ],
          };
        } else {
          payload.type = campaign.mediaUrl ? (campaign.mediaType || 'image') : 'text';
          payload.text = campaign.messageBody;
          if (campaign.mediaUrl) {
            payload.media = {
              url: campaign.mediaUrl,
              caption: campaign.messageBody,
              filename: campaign.mediaName,
            };
          }
        }

        const res = await fetch(`${API_BASE}/api/whatsapp/send`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });

        const resData = await res.json();

        if (res.ok && resData.success) {
          accepted++;
          recipientLogs.push({
            clientId: client.id,
            clientName: client.name,
            whatsappNumber: toWhatsAppApiFormat(client.whatsappNumber || client.mobile),
            status: 'Accepted' as const,
            wamid: resData.messageId || `wamid.HBg${Date.now()}`,
            sentAt: new Date().toISOString(),
          });
        } else {
          failed++;
          recipientLogs.push({
            clientId: client.id,
            clientName: client.name,
            whatsappNumber: toWhatsAppApiFormat(client.whatsappNumber || client.mobile),
            status: 'Failed' as const,
            errorCode: resData.metaError?.code?.toString() || 'API_ERROR',
            errorMessage: resData.error || 'WhatsApp API request failed',
          });
        }
      } catch (err: any) {
        failed++;
        recipientLogs.push({
          clientId: client.id,
          clientName: client.name,
          whatsappNumber: toWhatsAppApiFormat(client.whatsappNumber || client.mobile),
          status: 'Failed' as const,
          errorMessage: err.message,
        });
      }
    }

    setCampaigns((prev) =>
      prev.map((c) =>
        c.id === campaignId
          ? {
              ...c,
              status: 'Completed',
              sentAt: new Date().toISOString(),
              acceptedByApi: accepted,
              failedCount: failed,
              recipients: recipientLogs,
            }
          : c
      )
    );

    addAuditLog(
      'CAMPAIGN_LAUNCH',
      `Launched WhatsApp campaign "${campaign.name}" via Official Cloud API: ${accepted} accepted, ${failed} failed`
    );

    return {
      success: true,
      message: `WhatsApp Campaign processed: ${accepted} messages accepted by Meta Cloud API, ${failed} failed.`,
    };
  };

  const addFollowUp = (data: Omit<FollowUp, 'id'>) => {
    const id = `FLW-${Date.now().toString().slice(-4)}`;
    const newFollowUp: FollowUp = { ...data, id };
    setFollowUps((prev) => [newFollowUp, ...prev]);
    addAuditLog('FOLLOWUP_UPDATE', `Scheduled follow-up for client ${data.clientName} (${data.type})`);
  };

  const updateFollowUp = (updated: FollowUp) => {
    setFollowUps((prev) => prev.map((f) => (f.id === updated.id ? updated : f)));
    addAuditLog('FOLLOWUP_UPDATE', `Updated follow-up status for client ${updated.clientName}: ${updated.status}`);
  };

  const addSiteVisit = (data: Omit<SiteVisit, 'id'>) => {
    const id = `SV-${Date.now().toString().slice(-4)}`;
    const newVisit: SiteVisit = { ...data, id };
    setSiteVisits((prev) => [newVisit, ...prev]);
    addAuditLog('FOLLOWUP_UPDATE', `Scheduled site visit at ${data.projectName} for ${data.clientName}`);
  };

  const updateSiteVisit = (updated: SiteVisit) => {
    setSiteVisits((prev) => prev.map((v) => (v.id === updated.id ? updated : v)));
    addAuditLog('FOLLOWUP_UPDATE', `Updated site visit record for ${updated.clientName}: ${updated.status}`);
  };

  const addTemplate = (data: Omit<WhatsAppTemplate, 'id'>) => {
    const id = `tpl-${Date.now().toString().slice(-4)}`;
    const newTpl: WhatsAppTemplate = { ...data, id };
    setTemplates((prev) => [newTpl, ...prev]);
    addAuditLog('TEMPLATE_CREATE', `Created WhatsApp message template "${data.name}"`);
  };

  return (
    <CrmContext.Provider
      value={{
        clients,
        followUps,
        siteVisits,
        campaigns,
        templates,
        auditLogs,
        currentRole,
        activeTab,
        apiConfig,
        selectedClientIds,
        searchQuery,
        setCurrentRole,
        setActiveTab,
        setSearchQuery,
        addClient,
        updateClient,
        archiveClient,
        restoreClient,
        deleteClient,
        importClientsWithDuplicates,
        exportClients,
        toggleSelectClient,
        selectAllClients,
        clearSelection,
        createCampaign,
        launchCampaign,
        addFollowUp,
        updateFollowUp,
        addSiteVisit,
        updateSiteVisit,
        addTemplate,
        refreshApiStatus,
        addAuditLog,
      }}
    >
      {children}
    </CrmContext.Provider>
  );
};

export const useCrm = () => {
  const context = useContext(CrmContext);
  if (!context) {
    throw new Error('useCrm must be used within a CrmProvider');
  }
  return context;
};
