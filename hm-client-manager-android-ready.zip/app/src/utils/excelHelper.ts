/**
 * Excel and CSV import and export helpers for HM Client Manager
 * Uses SheetJS (xlsx)
 */

import * as XLSX from 'xlsx';
import { Client } from '../types';
import { normalizeIndianPhone, isValidIndianMobile, findClientDuplicates } from './clientValidation';

export interface ImportPreviewResult {
  validClients: Partial<Client>[];
  duplicateClients: Array<{
    candidate: Partial<Client>;
    existing: { id: string; name: string; mobile: string; whatsappNumber: string };
    matchField: 'mobile' | 'whatsappNumber';
  }>;
  invalidClients: Array<{ row: any; reason: string }>;
  totalRows: number;
}

export function exportClientsToExcel(clients: Client[], fileName: string = 'HM_Group_Clients.xlsx') {
  const exportData = clients.map((c) => ({
    'Client ID': c.id,
    'Client Name': c.name,
    'Mobile Number': c.mobile,
    'WhatsApp Number': c.whatsappNumber || c.mobile,
    'City': c.city,
    'Property Interest': c.propertyInterest,
    'Project Name': c.projectName,
    'Budget': c.budget,
    'Lead Source': c.leadSource,
    'Lead Status': c.leadStatus,
    'Assigned Sales Executive': c.assignedExecutive,
    'Last Contact Date': c.lastContactDate || '',
    'Next Follow-up Date': c.nextFollowUpDate || '',
    'WhatsApp Marketing Consent': c.whatsappConsent,
    'Notes': c.notes || '',
    'Archived': c.archived ? 'Yes' : 'No',
  }));

  const worksheet = XLSX.utils.json_to_sheet(exportData);
  
  // Set nice column widths
  worksheet['!cols'] = [
    { wch: 14 }, // Client ID
    { wch: 22 }, // Client Name
    { wch: 15 }, // Mobile
    { wch: 16 }, // WhatsApp
    { wch: 14 }, // City
    { wch: 24 }, // Property Interest
    { wch: 22 }, // Project Name
    { wch: 18 }, // Budget
    { wch: 16 }, // Lead Source
    { wch: 20 }, // Lead Status
    { wch: 20 }, // Executive
    { wch: 16 }, // Last Contact
    { wch: 16 }, // Next Followup
    { wch: 18 }, // Consent
    { wch: 30 }, // Notes
    { wch: 10 }, // Archived
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Clients');
  XLSX.writeFile(workbook, fileName);
}

export async function parseExcelOrCsvFile(
  file: File,
  existingClients: Client[]
): Promise<ImportPreviewResult> {
  const data = await file.arrayBuffer();
  const workbook = XLSX.read(data, { type: 'array' });
  const sheetName = workbook.SheetNames[0];
  const worksheet = workbook.Sheets[sheetName];
  const rawRows: Record<string, any>[] = XLSX.utils.sheet_to_json(worksheet, { defval: '' });

  const validClients: Partial<Client>[] = [];
  const duplicateClients: ImportPreviewResult['duplicateClients'] = [];
  const invalidClients: ImportPreviewResult['invalidClients'] = [];

  rawRows.forEach((row, index) => {
    // Flexible key matcher
    const getVal = (possibleKeys: string[]): string => {
      for (const key of Object.keys(row)) {
        const cleanKey = key.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
        for (const pk of possibleKeys) {
          if (cleanKey === pk.toLowerCase().replace(/[^a-z0-9]/g, '')) {
            return String(row[key] || '').trim();
          }
        }
      }
      return '';
    };

    const name = getVal(['clientname', 'name', 'customername', 'fullname', 'client']);
    const rawMobile = getVal(['mobilenumber', 'mobile', 'phone', 'contact', 'cell', 'phonenumber']);
    const rawWa = getVal(['whatsappnumber', 'whatsapp', 'wanumber', 'waphone']);
    const city = getVal(['city', 'location', 'town']) || 'Lucknow';
    const propertyInterest = getVal(['propertyinterest', 'interest', 'requirement', 'type', 'propertytype']) || '2 BHK Luxury Apartment';
    const projectName = getVal(['projectname', 'project', 'property']) || 'HM Royal Palms';
    const budget = getVal(['budget', 'budgetrange', 'price']) || '₹50 - ₹75 Lakhs';
    const leadSource = getVal(['leadsource', 'source', 'channel']) || 'Excel Import';
    const leadStatus = (getVal(['leadstatus', 'status']) || 'New Lead') as any;
    const assignedExecutive = getVal(['assignedsalesexecutive', 'salesexecutive', 'executive', 'agent', 'assignedto']) || 'Tariq Ansari';
    const lastContact = getVal(['lastcontactdate', 'lastcontact', 'lastcontacted']) || new Date().toISOString().split('T')[0];
    const nextFollowUp = getVal(['nextfollowupdate', 'nextfollowup', 'followup', 'nextcall']) || '';
    const notes = getVal(['notes', 'remarks', 'comment']);
    const rawConsent = getVal(['whatsappmarketingconsentstatus', 'whatsappconsent', 'consent', 'optin']);

    if (!name) {
      invalidClients.push({ row, reason: `Row #${index + 2}: Client name is missing` });
      return;
    }

    const cleanMobile = normalizeIndianPhone(rawMobile);
    if (!cleanMobile || !isValidIndianMobile(cleanMobile)) {
      invalidClients.push({
        row,
        reason: `Row #${index + 2} (${name}): Invalid Indian mobile number "${rawMobile}"`,
      });
      return;
    }

    const cleanWa = rawWa ? normalizeIndianPhone(rawWa) : cleanMobile;
    
    let whatsappConsent: 'Opted-in' | 'Opted-out' | 'Pending' = 'Opted-in';
    const lowerConsent = rawConsent.toLowerCase();
    if (lowerConsent.includes('out') || lowerConsent.includes('unsub') || lowerConsent.includes('no')) {
      whatsappConsent = 'Opted-out';
    } else if (lowerConsent.includes('pend')) {
      whatsappConsent = 'Pending';
    }

    const candidate: Partial<Client> = {
      name,
      mobile: cleanMobile,
      whatsappNumber: cleanWa,
      city,
      propertyInterest,
      projectName,
      budget,
      leadSource,
      leadStatus,
      assignedExecutive,
      lastContactDate: lastContact,
      nextFollowUpDate: nextFollowUp,
      notes: notes || 'Imported via Excel spreadsheet',
      whatsappConsent,
    };

    // Check duplicate against existing CRM clients
    const dupMatch = findClientDuplicates(
      { mobile: cleanMobile, whatsappNumber: cleanWa },
      existingClients
    );

    if (dupMatch) {
      duplicateClients.push({
        candidate,
        existing: dupMatch.matchedClient,
        matchField: dupMatch.matchField,
      });
    } else {
      validClients.push(candidate);
    }
  });

  return {
    validClients,
    duplicateClients,
    invalidClients,
    totalRows: rawRows.length,
  };
}
