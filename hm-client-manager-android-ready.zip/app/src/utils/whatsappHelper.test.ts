import test from 'node:test';
import assert from 'node:assert/strict';
import {
  renderTemplateText,
  calculateCampaignStats,
  categorizeClientsForCampaign,
} from './whatsappHelper.ts';

test('renderTemplateText substitutes numbered positional parameters', () => {
  const tpl = 'Namaste {{1}}, welcome to {{2}} in Lucknow! Contact your executive {{3}}.';
  const rendered = renderTemplateText(tpl, ['Sunil Gupta', 'HM Royal Palms', 'Tariq Ansari']);
  assert.equal(
    rendered,
    'Namaste Sunil Gupta, welcome to HM Royal Palms in Lucknow! Contact your executive Tariq Ansari.'
  );
});

test('renderTemplateText substitutes named keys', () => {
  const tpl = 'Hi {{name}}, special pre-launch offer for {{project}}!';
  const rendered = renderTemplateText(tpl, { name: 'Dr. Rastogi', project: 'HM Heights' });
  assert.equal(rendered, 'Hi Dr. Rastogi, special pre-launch offer for HM Heights!');
});

test('calculateCampaignStats calculates delivery percentages accurately', () => {
  const logs: Array<{ status: 'Accepted' | 'Delivered' | 'Read' | 'Failed' | 'Opted-Out' }> = [
    { status: 'Read' },
    { status: 'Read' },
    { status: 'Delivered' },
    { status: 'Accepted' },
    { status: 'Failed' },
  ];

  const stats = calculateCampaignStats(logs);
  assert.equal(stats.total, 5);
  assert.equal(stats.accepted, 4); // 2 read + 1 delivered + 1 accepted
  assert.equal(stats.delivered, 3); // 2 read + 1 delivered
  assert.equal(stats.read, 2);
  assert.equal(stats.failed, 1);
  assert.equal(stats.acceptanceRate, 80); // 4/5 = 80%
  assert.equal(stats.deliveryRate, 75); // 3/4 = 75%
  assert.equal(stats.readRate, 67); // 2/3 = 67%
});

test('categorizeClientsForCampaign filters out opted-out and invalid numbers', () => {
  const clients = [
    { id: '1', name: 'Valid User', mobile: '9876543210', whatsappConsent: 'Opted-in' },
    { id: '2', name: 'Opted Out User', mobile: '9123456789', whatsappConsent: 'Opted-out' },
    { id: '3', name: 'Invalid User', mobile: '12345', whatsappConsent: 'Opted-in' },
  ];

  const result = categorizeClientsForCampaign(clients);
  assert.equal(result.eligible.length, 1);
  assert.equal(result.eligible[0].id, '1');
  assert.equal(result.optedOut.length, 1);
  assert.equal(result.optedOut[0].id, '2');
  assert.equal(result.invalid.length, 1);
  assert.equal(result.invalid[0].id, '3');
});
