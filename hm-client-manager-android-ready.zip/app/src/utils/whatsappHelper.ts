/**
 * WhatsApp message rendering, template processing, and stats calculations
 * Official Meta WhatsApp Business Cloud API compliant
 */

import { checkWhatsAppEligibility } from './clientValidation.ts';

export interface RecipientStats {
  total: number;
  accepted: number;
  delivered: number;
  read: number;
  failed: number;
  acceptanceRate: number; // percentage
  deliveryRate: number; // percentage
  readRate: number; // percentage
}

/**
 * Replaces placeholders like {{1}}, {{2}}, or {{name}} with variable values
 */
export function renderTemplateText(
  templateBody: string,
  variables: Record<string, string> | string[]
): string {
  if (!templateBody) return '';

  if (Array.isArray(variables)) {
    return templateBody.replace(/\{\{(\d+)\}\}/g, (match, index) => {
      const idx = parseInt(index, 10) - 1;
      return variables[idx] !== undefined ? variables[idx] : match;
    });
  }

  return templateBody.replace(/\{\{([a-zA-Z0-9_]+)\}\}/g, (match, key) => {
    return variables[key] !== undefined ? variables[key] : match;
  });
}

/**
 * Calculates delivery statistics from campaign recipient logs
 */
export function calculateCampaignStats(
  recipients: Array<{ status: 'Accepted' | 'Delivered' | 'Read' | 'Failed' | 'Opted-Out' }>
): RecipientStats {
  const total = recipients.length;
  let accepted = 0;
  let delivered = 0;
  let read = 0;
  let failed = 0;

  for (const r of recipients) {
    if (r.status === 'Accepted' || r.status === 'Delivered' || r.status === 'Read') {
      accepted++;
    }
    if (r.status === 'Delivered' || r.status === 'Read') {
      delivered++;
    }
    if (r.status === 'Read') {
      read++;
    }
    if (r.status === 'Failed') {
      failed++;
    }
  }

  const acceptanceRate = total > 0 ? Math.round((accepted / total) * 100) : 0;
  const deliveryRate = accepted > 0 ? Math.round((delivered / accepted) * 100) : 0;
  const readRate = delivered > 0 ? Math.round((read / delivered) * 100) : 0;

  return {
    total,
    accepted,
    delivered,
    read,
    failed,
    acceptanceRate,
    deliveryRate,
    readRate,
  };
}

/**
 * Categorizes a list of candidate clients into eligible, opted-out, and invalid
 */
export function categorizeClientsForCampaign<T extends {
  id: string;
  name: string;
  mobile: string;
  whatsappNumber?: string;
  whatsappConsent: string;
  archived?: boolean;
}>(clients: T[]) {
  const eligible: T[] = [];
  const optedOut: T[] = [];
  const invalid: T[] = [];

  for (const client of clients) {
    const check = checkWhatsAppEligibility(client);
    if (check.eligible) {
      eligible.push(client);
    } else if (client.whatsappConsent === 'Opted-out') {
      optedOut.push(client);
    } else {
      invalid.push(client);
    }
  }

  return {
    eligible,
    optedOut,
    invalid,
  };
}
