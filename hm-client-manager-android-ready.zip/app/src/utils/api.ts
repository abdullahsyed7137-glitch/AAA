// Base URL of the hosted backend (server.ts). Empty = same origin (web).
// For the Android APK, set VITE_API_BASE to your deployed server URL, e.g. https://your-app.run.app
export const API_BASE: string = ((import.meta as any).env?.VITE_API_BASE || '').replace(/\/$/, '');
