/**
 * Client and phone validation utilities for HM Client Manager
 * Lucknow, Uttar Pradesh, India
 */

/**
 * Normalizes an Indian phone number:
 * - Strips all non-digit characters except leading '+'
 * - Removes leading '0' or '+91' or '91' if 10 digits follow
 * - Returns clean 10-digit number for Indian mobiles
 */
export function normalizeIndianPhone(input: string | undefined | null): string {
  if (!input) return '';
  // Remove non-digit characters
  const digits = input.replace(/\D/g, '');

  // If 12 digits starting with 91, strip 91
  if (digits.length === 12 && digits.startsWith('91')) {
    return digits.slice(2);
  }

  // If 11 digits starting with 0, strip 0
  if (digits.length === 11 && digits.startsWith('0')) {
    return digits.slice(1);
  }

  // If exactly 10 digits, return it
  if (digits.length === 10) {
    return digits;
  }

  // Return raw digits if different length
  return digits;
}

/**
 * Validates if the phone number is a valid 10-digit Indian mobile number
 * (Starts with 6, 7, 8, or 9)
 */
export function isValidIndianMobile(input: string | undefined | null): boolean {
  if (!input) return false;
  const normalized = normalizeIndianPhone(input);
  return /^[6-9]\d{9}$/.test(normalized);
}

/**
 * Formats a phone number for display (+91 XXXXX XXXXX)
 */
export function formatIndianMobileDisplay(input: string | undefined | null): string {
  if (!input) return 'N/A';
  const normalized = normalizeIndianPhone(input);
  if (normalized.length === 10) {
    return `+91 ${normalized.slice(0, 5)} ${normalized.slice(5)}`;
  }
  return input;
}

/**
 * Formats phone number into international WhatsApp E.164 without plus (+91XXXXXXXXXX)
 * Required by WhatsApp Cloud API
 */
export function toWhatsAppApiFormat(input: string | undefined | null): string {
  if (!input) return '';
  const normalized = normalizeIndianPhone(input);
  if (normalized.length === 10) {
    return `91${normalized}`;
  }
  return normalized;
}

export interface DuplicateMatch {
  matchField: 'mobile' | 'whatsappNumber';
  matchedClient: {
    id: string;
    name: string;
    mobile: string;
    whatsappNumber: string;
  };
}

/**
 * Detects duplicate clients based on mobile or whatsappNumber
 */
export function findClientDuplicates(
  candidate: { id?: string; mobile?: string; whatsappNumber?: string },
  existingClients: Array<{ id: string; name: string; mobile: string; whatsappNumber: string }>
): DuplicateMatch | null {
  const normMobile = normalizeIndianPhone(candidate.mobile);
  const normWa = normalizeIndianPhone(candidate.whatsappNumber || candidate.mobile);

  for (const existing of existingClients) {
    // Skip checking against itself if editing
    if (candidate.id && existing.id === candidate.id) continue;

    const existMobile = normalizeIndianPhone(existing.mobile);
    const existWa = normalizeIndianPhone(existing.whatsappNumber);

    if (normMobile && (normMobile === existMobile || normMobile === existWa)) {
      return {
        matchField: 'mobile',
        matchedClient: existing,
      };
    }

    if (normWa && (normWa === existMobile || normWa === existWa)) {
      return {
        matchField: 'whatsappNumber',
        matchedClient: existing,
      };
    }
  }

  return null;
}

/**
 * Checks WhatsApp marketing eligibility strictly
 */
export function checkWhatsAppEligibility(client: {
  mobile: string;
  whatsappNumber?: string;
  whatsappConsent: string;
  archived?: boolean;
}): { eligible: boolean; reason?: string } {
  if (client.archived) {
    return { eligible: false, reason: 'Client record is archived' };
  }

  if (client.whatsappConsent === 'Opted-out') {
    return { eligible: false, reason: 'Client has explicitly opted out / unsubscribed' };
  }

  if (client.whatsappConsent === 'Pending') {
    return { eligible: false, reason: 'Consent status is pending verification' };
  }

  const phone = client.whatsappNumber || client.mobile;
  if (!isValidIndianMobile(phone)) {
    return { eligible: false, reason: 'Invalid mobile or WhatsApp number format' };
  }

  return { eligible: true };
}
