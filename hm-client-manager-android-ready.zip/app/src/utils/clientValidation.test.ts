import test from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizeIndianPhone,
  isValidIndianMobile,
  formatIndianMobileDisplay,
  toWhatsAppApiFormat,
  findClientDuplicates,
  checkWhatsAppEligibility,
} from './clientValidation.ts';

test('normalizeIndianPhone handles standard 10-digit number', () => {
  assert.equal(normalizeIndianPhone('9876543210'), '9876543210');
});

test('normalizeIndianPhone strips +91 country code and spaces', () => {
  assert.equal(normalizeIndianPhone('+91 98765 43210'), '9876543210');
  assert.equal(normalizeIndianPhone('91-9876543210'), '9876543210');
});

test('normalizeIndianPhone strips leading zero', () => {
  assert.equal(normalizeIndianPhone('09876543210'), '9876543210');
});

test('isValidIndianMobile validates valid Indian mobile prefixes (6, 7, 8, 9)', () => {
  assert.equal(isValidIndianMobile('9876543210'), true);
  assert.equal(isValidIndianMobile('+91 8123456789'), true);
  assert.equal(isValidIndianMobile('7012345678'), true);
  assert.equal(isValidIndianMobile('6301234567'), true);
});

test('isValidIndianMobile rejects invalid numbers', () => {
  assert.equal(isValidIndianMobile('5123456789'), false); // Starts with 5
  assert.equal(isValidIndianMobile('12345'), false); // Too short
  assert.equal(isValidIndianMobile(''), false);
  assert.equal(isValidIndianMobile(null as any), false);
});

test('formatIndianMobileDisplay formats properly', () => {
  assert.equal(formatIndianMobileDisplay('9876543210'), '+91 98765 43210');
  assert.equal(formatIndianMobileDisplay(''), 'N/A');
});

test('toWhatsAppApiFormat formats without plus sign for Meta Cloud API', () => {
  assert.equal(toWhatsAppApiFormat('9876543210'), '919876543210');
  assert.equal(toWhatsAppApiFormat('+91 98765 43210'), '919876543210');
});

test('findClientDuplicates detects duplicate by mobile or whatsappNumber', () => {
  const existing = [
    { id: '1', name: 'Alok Verma', mobile: '9876543210', whatsappNumber: '9876543210' },
    { id: '2', name: 'Zoya Khan', mobile: '9123456789', whatsappNumber: '9123456789' },
  ];

  const match1 = findClientDuplicates({ mobile: '+91 98765 43210' }, existing);
  assert.ok(match1);
  assert.equal(match1.matchedClient.id, '1');

  const match2 = findClientDuplicates({ whatsappNumber: '09123456789', mobile: '9000000000' }, existing);
  assert.ok(match2);
  assert.equal(match2.matchedClient.id, '2');

  const noMatch = findClientDuplicates({ mobile: '9999988888' }, existing);
  assert.equal(noMatch, null);
});

test('checkWhatsAppEligibility respects consent and validity', () => {
  assert.equal(
    checkWhatsAppEligibility({
      mobile: '9876543210',
      whatsappConsent: 'Opted-in',
    }).eligible,
    true
  );

  assert.equal(
    checkWhatsAppEligibility({
      mobile: '9876543210',
      whatsappConsent: 'Opted-out',
    }).eligible,
    false
  );

  assert.equal(
    checkWhatsAppEligibility({
      mobile: '12345',
      whatsappConsent: 'Opted-in',
    }).eligible,
    false
  );
});
