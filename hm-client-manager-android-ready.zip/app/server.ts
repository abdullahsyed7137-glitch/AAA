import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);

// CORS so the Android app (served from https://localhost inside the APK) can call this API
app.use((req: Request, res: Response, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Helper to get WhatsApp Config
function getWhatsAppConfig() {
  const token = process.env.WHATSAPP_ACCESS_TOKEN || '';
  const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID || '';
  const businessAccountId = process.env.WHATSAPP_BUSINESS_ACCOUNT_ID || '';
  const verifyToken = process.env.WHATSAPP_WEBHOOK_VERIFY_TOKEN || 'hm_group_lucknow_crm_2025';

  return {
    isConfigured: Boolean(token && phoneNumberId),
    hasToken: Boolean(token),
    phoneNumberId,
    businessAccountId,
    verifyToken,
    token,
  };
}

// 1. WhatsApp API Status Endpoint
app.get('/api/whatsapp/status', (_req: Request, res: Response) => {
  const config = getWhatsAppConfig();
  res.json({
    isConfigured: config.isConfigured,
    hasToken: config.hasToken,
    phoneNumberId: config.phoneNumberId ? `${config.phoneNumberId.slice(0, 4)}...${config.phoneNumberId.slice(-4)}` : '',
    rawPhoneNumberId: config.phoneNumberId,
    businessAccountId: config.businessAccountId,
    webhookVerifyToken: config.verifyToken,
  });
});

// 2. WhatsApp Official Cloud API Message Send Endpoint
app.post('/api/whatsapp/send', async (req: Request, res: Response) => {
  const config = getWhatsAppConfig();
  const { to, type, template, text, media, recipientName } = req.body;

  if (!to) {
    return res.status(400).json({
      success: false,
      error: 'Recipient phone number (to) is required in international E.164 format (e.g. 919839012345)',
    });
  }

  // If not configured, strictly do not simulate! Return explicit status as required
  if (!config.isConfigured) {
    return res.status(503).json({
      success: false,
      isConfigured: false,
      error: 'WhatsApp Business Cloud API is not configured on the backend. Please provide WHATSAPP_ACCESS_TOKEN and WHATSAPP_PHONE_NUMBER_ID.',
      setupRequired: true,
    });
  }

  try {
    const metaGraphUrl = `https://graph.facebook.com/v19.0/${config.phoneNumberId}/messages`;
    
    // Build Meta payload
    let payload: any = {
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to: to.replace(/\D/g, ''),
    };

    if (type === 'template') {
      payload.type = 'template';
      payload.template = {
        name: template.name,
        language: {
          code: template.language || 'en_US',
        },
      };

      if (template.components && Array.isArray(template.components)) {
        payload.template.components = template.components;
      }
    } else if (type === 'image' && media?.url) {
      payload.type = 'image';
      payload.image = {
        link: media.url,
        caption: media.caption || text || '',
      };
    } else if (type === 'document' && media?.url) {
      payload.type = 'document';
      payload.document = {
        link: media.url,
        caption: media.caption || text || '',
        filename: media.filename || 'HM_Group_Document.pdf',
      };
    } else {
      payload.type = 'text';
      payload.text = {
        preview_url: true,
        body: text || '',
      };
    }

    const response = await fetch(metaGraphUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${config.token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(response.status).json({
        success: false,
        error: data.error?.message || 'Meta WhatsApp API returned an error',
        metaError: data.error,
      });
    }

    return res.json({
      success: true,
      metaResponse: data,
      messageId: data.messages?.[0]?.id,
      recipient: to,
    });
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      error: err.message || 'Internal server error while communicating with WhatsApp API',
    });
  }
});

// 3. Webhook verification for Meta Developer Portal
app.get('/api/whatsapp/webhook', (req: Request, res: Response) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];
  const config = getWhatsAppConfig();

  if (mode && token) {
    if (mode === 'subscribe' && token === config.verifyToken) {
      return res.status(200).send(challenge);
    } else {
      return res.sendStatus(403);
    }
  }
  res.sendStatus(400);
});

// 4. Webhook listener for incoming delivery receipts and replies
app.post('/api/whatsapp/webhook', (req: Request, res: Response) => {
  const body = req.body;
  if (body.object === 'whatsapp_business_account') {
    // Process entry, changes, messages, statuses
    res.status(200).send('EVENT_RECEIVED');
  } else {
    res.sendStatus(404);
  }
});

// 5. Mount Vite or static server
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`HM Client Manager server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
